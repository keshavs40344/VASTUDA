// Staunt Browser Ultra — Secure Sandboxed IPC Preload Bridge
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('stauntAPI', {
  // Tabs Lifecycle
  createTab: (url, opts) => ipcRenderer.send('create-tab', url, opts),
  switchTab: (tabId) => ipcRenderer.send('switch-tab', tabId),
  closeTab: (tabId) => ipcRenderer.send('close-tab', tabId),
  toggleSplitView: (secId) => ipcRenderer.send('toggle-split-view', secId),
  toggleMuteTab: (tabId) => ipcRenderer.send('toggle-mute-tab', tabId),

  // Navigation API
  navigate: (url) => ipcRenderer.send('navigate-to', url),
  goBack: () => ipcRenderer.send('go-back'),
  goForward: () => ipcRenderer.send('go-forward'),
  reload: () => ipcRenderer.send('reload-page'),

  // Layout & Shell State
  setSidebarState: (isCollapsed) => ipcRenderer.send('set-sidebar-state', isCollapsed),
  clearCache: () => ipcRenderer.send('clear-browser-cache'),
  toggleDevTools: () => ipcRenderer.send('toggle-devtools'),

  // Window Controls
  minimizeWindow: () => ipcRenderer.send('window-minimize'),
  maximizeWindow: () => ipcRenderer.send('window-maximize'),
  closeWindow: () => ipcRenderer.send('window-close'),

  // Event Listeners from Main Process
  onTabCreated: (cb) => ipcRenderer.on('tab-created', (e, data) => cb(data)),
  onTabUpdated: (cb) => ipcRenderer.on('tab-updated', (e, data) => cb(data)),
  onTabClosed: (cb) => ipcRenderer.on('tab-closed', (e, tabId) => cb(tabId)),
  onTabSwitched: (cb) => ipcRenderer.on('tab-switched', (e, data) => cb(data)),
  onSplitViewUpdated: (cb) => ipcRenderer.on('split-view-updated', (e, data) => cb(data)),
  onShieldUpdated: (cb) => ipcRenderer.on('shield-updated', (e, data) => cb(data)),
  onPermissionRequested: (cb) => ipcRenderer.on('permission-requested', (e, data) => cb(data))
});
