// Staunt Browser Ultra — Secure Sandboxed IPC Preload Bridge
// 100% Comprehensive Blueprint IPC Exposure
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('stauntAPI', {
  // Tabs Lifecycle
  createTab: (url, opts) => ipcRenderer.send('create-tab', url, opts),
  switchTab: (tabId) => ipcRenderer.send('switch-tab', tabId),
  closeTab: (tabId) => ipcRenderer.send('close-tab', tabId),
  undoCloseTab: () => ipcRenderer.send('undo-close-tab'),
  toggleSplitView: (secId) => ipcRenderer.send('toggle-split-view', secId),
  toggleMuteTab: (tabId) => ipcRenderer.send('toggle-mute-tab', tabId),

  // Navigation API
  navigate: (url) => ipcRenderer.send('navigate-to', url),
  goBack: () => ipcRenderer.send('go-back'),
  goForward: () => ipcRenderer.send('go-forward'),
  reload: () => ipcRenderer.send('reload-page'),

  // Find In Page API
  findInPage: (text, forward) => ipcRenderer.send('find-in-page', text, forward),
  stopFindInPage: () => ipcRenderer.send('stop-find-in-page'),

  // Page Zoom & PDF Export
  setZoom: (level) => ipcRenderer.send('set-zoom', level),
  printToPDF: () => ipcRenderer.send('print-to-pdf'),

  // History & Bookmarks Query API
  getHistory: () => ipcRenderer.invoke('get-history'),
  getBookmarks: () => ipcRenderer.invoke('get-bookmarks'),
  addBookmark: (item) => ipcRenderer.send('add-bookmark', item),

  // Layout & Shell State
  setSidebarState: (isCollapsed) => ipcRenderer.send('set-sidebar-state', isCollapsed),
  clearCache: () => ipcRenderer.send('clear-browser-cache'),
  toggleDevTools: () => ipcRenderer.send('toggle-devtools'),

  // Window Controls
  minimizeWindow: () => ipcRenderer.send('window-minimize'),
  maximizeWindow: () => ipcRenderer.send('window-maximize'),
  closeWindow: () => ipcRenderer.send('window-close'),

  // Event Listeners from Main Process
  onTabCreated: (cb) => ipcRenderer.on('tab-created', (e, data) => cb(data)),
  onTabUpdated: (cb) => ipcRenderer.on('tab-updated', (e, data) => cb(data)),
  onTabClosed: (cb) => ipcRenderer.on('tab-closed', (e, tabId) => cb(tabId)),
  onTabSwitched: (cb) => ipcRenderer.on('tab-switched', (e, data) => cb(data)),
  onTabCrashed: (cb) => ipcRenderer.on('tab-crashed', (e, data) => cb(data)),
  onSplitViewUpdated: (cb) => ipcRenderer.on('split-view-updated', (e, data) => cb(data)),
  onShieldUpdated: (cb) => ipcRenderer.on('shield-updated', (e, data) => cb(data)),
  onPermissionRequested: (cb) => ipcRenderer.on('permission-requested', (e, data) => cb(data)),
  onFindResult: (cb) => ipcRenderer.on('find-result', (e, data) => cb(data)),
  onDownloadProgress: (cb) => ipcRenderer.on('download-progress', (e, data) => cb(data)),
  onDownloadComplete: (cb) => ipcRenderer.on('download-complete', (e, data) => cb(data))
});
