const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('stauntAPI', {
  // Tabs API
  createTab: (url) => ipcRenderer.send('create-tab', url),
  switchTab: (tabId) => ipcRenderer.send('switch-tab', tabId),
  closeTab: (tabId) => ipcRenderer.send('close-tab', tabId),

  // Navigation API
  navigate: (url) => ipcRenderer.send('navigate-to', url),
  goBack: () => ipcRenderer.send('go-back'),
  goForward: () => ipcRenderer.send('go-forward'),
  reload: () => ipcRenderer.send('reload-page'),
  goHome: () => ipcRenderer.send('go-home'),

  // Window Controls
  minimizeWindow: () => ipcRenderer.send('window-minimize'),
  maximizeWindow: () => ipcRenderer.send('window-maximize'),
  closeWindow: () => ipcRenderer.send('window-close'),

  // DevTools & Utilities
  toggleDevTools: () => ipcRenderer.send('toggle-devtools'),
  toggleReaderMode: () => ipcRenderer.send('toggle-reader-mode'),
  togglePip: () => ipcRenderer.send('toggle-pip'),
  setDrawerState: (isOpen) => ipcRenderer.send('set-drawer-state', isOpen),
  
  // Media Sniffer & Downloader
  downloadMedia: (mediaUrl) => ipcRenderer.send('download-media', mediaUrl),

  // Events from Main Process
  onTabCreated: (callback) => ipcRenderer.on('tab-created', (e, data) => callback(data)),
  onTabUpdated: (callback) => ipcRenderer.on('tab-updated', (e, data) => callback(data)),
  onTabClosed: (callback) => ipcRenderer.on('tab-closed', (e, tabId) => callback(tabId)),
  onTabSwitched: (callback) => ipcRenderer.on('tab-switched', (e, tabId) => callback(tabId)),
  onShieldUpdated: (callback) => ipcRenderer.on('shield-updated', (e, data) => callback(data)),
  onMediaDetected: (callback) => ipcRenderer.on('media-detected', (e, data) => callback(data)),
  onNavStateChanged: (callback) => ipcRenderer.on('nav-state-changed', (e, data) => callback(data))
});
