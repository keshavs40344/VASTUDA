// Staunt Browser Ultra — Enterprise Main Process Engine
// Direct Chromium Backend (Blink + V8) with Multi-Process WebContentsView Isolation

const { app, BrowserWindow, WebContentsView, BrowserView, session, ipcMain, shell, Menu } = require('electron');
const path = require('path');
const { setupStauntShield, getShieldStats } = require('./src/adblocker');

// 1. Hardware Acceleration & Low-Latency Video Pipeline
app.commandLine.appendSwitch('enable-gpu-rasterization');
app.commandLine.appendSwitch('enable-zero-copy');
app.commandLine.appendSwitch('ignore-gpu-blocklist');
app.commandLine.appendSwitch('enable-features', 'VaapiVideoDecoder,CanvasOopRasterization,SmoothScrolling');
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

let mainWindow = null;
let tabs = new Map();
let activeTabId = null;
let secondaryTabId = null; // Split view tab
let nextTabId = 1;

// Dock & Layout Sizing State
let isSidebarCollapsed = false;
let isSplitViewActive = false;
let splitRatio = 0.5; // 50/50 split

const TOOLBAR_HEIGHT = 42; // Minimal spatial topbar
const DOCK_WIDTH_EXPANDED = 240;
const DOCK_WIDTH_COLLAPSED = 64;

function getDockWidth() {
  return isSidebarCollapsed ? DOCK_WIDTH_COLLAPSED : DOCK_WIDTH_EXPANDED;
}

// =============================================================================
// MAIN WINDOW INITIALIZATION
// =============================================================================
function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    frame: false,
    backgroundColor: '#0c0d0e',
    titleBarStyle: 'hidden',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false // Shell controller has sandboxed IPC bridge
    }
  });

  Menu.setApplicationMenu(null);
  mainWindow.loadFile(path.join(__dirname, 'src', 'index.html'));

  // Initialize Network-Layer Ad/Tracker Shield
  setupStauntShield(session.defaultSession, (event) => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('shield-updated', event.stats);
    }
  });

  // Granular Permission Gate (Camera, Mic, Geo, Notifications, Screen)
  session.defaultSession.setPermissionRequestHandler((webContents, permission, callback, details) => {
    const url = details.requestingUrl || webContents.getURL();
    console.log(`[PERMISSION GATE] Request: ${permission} from ${url}`);

    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('permission-requested', {
        permission: permission,
        url: url
      });
    }
    callback(true);
  });

  mainWindow.on('resize', () => updateLayoutBounds());
  mainWindow.on('closed', () => {
    mainWindow = null;
    tabs.clear();
  });
}

// =============================================================================
// SPATIAL VIEW BOUNDS MANAGER (Single & Split-View Side-by-Side)
// =============================================================================
function updateLayoutBounds() {
  if (!mainWindow || mainWindow.isDestroyed()) return;

  const bounds = mainWindow.getContentBounds();
  const dockWidth = getDockWidth();
  const availableWidth = Math.max(bounds.width - dockWidth - 12, 300);
  const availableHeight = Math.max(bounds.height - TOOLBAR_HEIGHT - 12, 200);
  const startX = dockWidth + 6;
  const startY = TOOLBAR_HEIGHT + 6;

  const activeTab = tabs.get(activeTabId);
  const secondaryTab = tabs.get(secondaryTabId);

  if (!isSplitViewActive || !secondaryTab) {
    // Single View
    if (activeTab && activeTab.view && activeTab.view.setBounds) {
      activeTab.view.setBounds({
        x: startX,
        y: startY,
        width: availableWidth,
        height: availableHeight
      });
    }
  } else {
    // Side-by-Side Split View
    const leftWidth = Math.floor(availableWidth * splitRatio);
    const rightWidth = availableWidth - leftWidth - 6;

    if (activeTab && activeTab.view && activeTab.view.setBounds) {
      activeTab.view.setBounds({
        x: startX,
        y: startY,
        width: leftWidth,
        height: availableHeight
      });
    }

    if (secondaryTab && secondaryTab.view && secondaryTab.view.setBounds) {
      secondaryTab.view.setBounds({
        x: startX + leftWidth + 6,
        y: startY,
        width: rightWidth,
        height: availableHeight
      });
    }
  }
}

// =============================================================================
// MULTI-PROCESS TAB ENGINE (WebContentsView / Process Isolation)
// =============================================================================
function createTab(initialUrl = 'staunt://newtab', options = {}) {
  const tabId = nextTabId++;
  const isIncognito = !!options.isIncognito;

  // Dedicated Session: Standard or Ephemeral In-Memory Incognito
  const tabSession = isIncognito 
    ? session.fromPartition(`incognito-${Date.now()}-${tabId}`, { cache: false }) 
    : session.defaultSession;

  // Chromium WebPreferences: 100% web app compatibility with strict isolation
  const webPrefs = {
    sandbox: true,
    contextIsolation: true,
    webSecurity: true,
    allowRunningInsecureContent: false,
    session: tabSession,
    plugins: true,
    enableWebSQL: false
  };

  let view;
  if (typeof WebContentsView !== 'undefined') {
    view = new WebContentsView({ webPreferences: webPrefs });
  } else {
    view = new BrowserView({ webPreferences: webPrefs });
  }

  const tabObj = {
    id: tabId,
    view: view,
    url: initialUrl,
    title: initialUrl === 'staunt://newtab' ? 'New Tab' : initialUrl,
    favicon: '',
    workspaceId: options.workspaceId || 'personal',
    isPinned: !!options.isPinned,
    isIncognito: isIncognito,
    isHibernated: false,
    lastActiveTime: Date.now(),
    isAudioPlaying: false,
    isMuted: false,
    canGoBack: false,
    canGoForward: false
  };

  tabs.set(tabId, tabObj);
  setupWebContentsEvents(tabObj);

  const formattedUrl = formatUrlOrSearch(initialUrl);
  view.webContents.loadURL(formattedUrl);

  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('tab-created', serializeTab(tabObj));
  }

  switchTab(tabId);
  return tabId;
}

function setupWebContentsEvents(tabObj) {
  const wc = tabObj.view.webContents;

  // Title & Favicon Trackers
  wc.on('page-title-updated', (e, title) => {
    tabObj.title = title;
    tabObj.lastActiveTime = Date.now();
    notifyTabUpdated(tabObj);
  });

  wc.on('page-favicon-updated', (e, favicons) => {
    if (favicons && favicons.length > 0) {
      tabObj.favicon = favicons[0];
      notifyTabUpdated(tabObj);
    }
  });

  // Navigation State
  wc.on('did-start-navigation', (e, url, isInPlace, isMainFrame) => {
    if (isMainFrame) {
      tabObj.url = url;
      tabObj.lastActiveTime = Date.now();
      tabObj.canGoBack = wc.canGoBack();
      tabObj.canGoForward = wc.canGoForward();
      notifyTabUpdated(tabObj);
    }
  });

  wc.on('did-finish-load', () => {
    tabObj.url = wc.getURL();
    tabObj.canGoBack = wc.canGoBack();
    tabObj.canGoForward = wc.canGoForward();
    notifyTabUpdated(tabObj);
  });

  // Audio Playback Indicator
  wc.on('media-started-playing', () => {
    tabObj.isAudioPlaying = true;
    notifyTabUpdated(tabObj);
  });

  wc.on('media-paused', () => {
    tabObj.isAudioPlaying = false;
    notifyTabUpdated(tabObj);
  });

  // Inject Brave-Style Surrogates
  wc.on('dom-ready', () => {
    wc.executeJavaScript(`
      (() => {
        if (window.__STAUNT_SURROGATES_INJECTED__) return;
        window.__STAUNT_SURROGATES_INJECTED__ = true;
        window.dataLayer = window.dataLayer || [];
        window.gtag = window.gtag || function() { window.dataLayer.push(arguments); };
        window.ga = window.ga || function() { (window.ga.q = window.ga.q || []).push(arguments); };
        window.fbq = window.fbq || function() {};
        window.google_ad_client = null;
        window.googletag = window.googletag || {
          cmd: [], display: function() {}, pubads: function() {
            return {
              enableSingleRequest: function() {}, addService: function() {},
              setTargeting: function() {}, collapseEmptyDivs: function() {},
              addEventListener: function() {}
            };
          },
          sizeMapping: function() { return { addSize: function() { return this; }, build: function() { return []; } }; },
          enableServices: function() {}
        };
        window.optimizely = window.optimizely || [];
      })();
    `).catch(() => {});
  });
}

function notifyTabUpdated(tabObj) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('tab-updated', serializeTab(tabObj));
  }
}

function serializeTab(tab) {
  return {
    id: tab.id,
    url: tab.url,
    title: tab.title,
    favicon: tab.favicon,
    workspaceId: tab.workspaceId,
    isPinned: tab.isPinned,
    isIncognito: tab.isIncognito,
    isHibernated: tab.isHibernated,
    isAudioPlaying: tab.isAudioPlaying,
    isMuted: tab.isMuted,
    canGoBack: tab.canGoBack,
    canGoForward: tab.canGoForward
  };
}

// =============================================================================
// TAB SWITCHING & ATTACHMENT
// =============================================================================
function switchTab(tabId) {
  if (!tabs.has(tabId)) return;
  const targetTab = tabs.get(tabId);

  // Auto-wake if hibernated
  if (targetTab.isHibernated) {
    wakeHibernatedTab(targetTab);
  }

  // Detach prior active view if not in split view
  if (activeTabId && activeTabId !== tabId && activeTabId !== secondaryTabId) {
    detachTabView(tabs.get(activeTabId));
  }

  activeTabId = tabId;
  targetTab.lastActiveTime = Date.now();

  attachTabView(targetTab);
  updateLayoutBounds();

  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('tab-switched', {
      activeTabId: activeTabId,
      secondaryTabId: secondaryTabId,
      isSplit: isSplitViewActive
    });
  }
}

function attachTabView(tabObj) {
  if (!mainWindow || !tabObj || !tabObj.view) return;
  if (mainWindow.contentView && mainWindow.contentView.addChildView) {
    mainWindow.contentView.addChildView(tabObj.view);
  } else if (mainWindow.setBrowserView) {
    mainWindow.setBrowserView(tabObj.view);
  }
}

function detachTabView(tabObj) {
  if (!mainWindow || !tabObj || !tabObj.view) return;
  if (mainWindow.contentView && mainWindow.contentView.removeChildView) {
    try { mainWindow.contentView.removeChildView(tabObj.view); } catch(e) {}
  } else if (mainWindow.removeBrowserView) {
    try { mainWindow.removeBrowserView(tabObj.view); } catch(e) {}
  }
}

function closeTab(tabId) {
  if (!tabs.has(tabId)) return;
  const tab = tabs.get(tabId);

  detachTabView(tab);

  try {
    if (tab.view && tab.view.webContents && !tab.view.webContents.isDestroyed()) {
      tab.view.webContents.close();
    }
  } catch(e) {}

  tabs.delete(tabId);

  if (secondaryTabId === tabId) {
    secondaryTabId = null;
    isSplitViewActive = false;
  }

  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('tab-closed', tabId);
  }

  if (activeTabId === tabId) {
    if (tabs.size > 0) {
      const remaining = Array.from(tabs.keys());
      switchTab(remaining[remaining.length - 1]);
    } else {
      createTab('staunt://newtab');
    }
  }
}

// =============================================================================
// TAB SLEEP / HIBERNATION ENGINE (>60% RAM SAVINGS)
// =============================================================================
setInterval(() => {
  const now = Date.now();
  const HIBERNATE_THRESHOLD = 15 * 60 * 1000; // 15 minutes inactive

  tabs.forEach((tab) => {
    if (
      !tab.isHibernated &&
      tab.id !== activeTabId &&
      tab.id !== secondaryTabId &&
      !tab.isAudioPlaying &&
      (now - tab.lastActiveTime > HIBERNATE_THRESHOLD)
    ) {
      console.log(`[RAM HIBERNATION] Sleeping tab ${tab.id}: ${tab.title}`);
      detachTabView(tab);
      try {
        if (tab.view && tab.view.webContents && !tab.view.webContents.isDestroyed()) {
          tab.view.webContents.close();
        }
      } catch(e) {}
      tab.isHibernated = true;
      notifyTabUpdated(tab);
    }
  });
}, 60000);

function wakeHibernatedTab(tab) {
  console.log(`[RAM HIBERNATION] Waking tab ${tab.id}: ${tab.url}`);
  const webPrefs = {
    sandbox: true,
    contextIsolation: true,
    webSecurity: true,
    allowRunningInsecureContent: false,
    session: session.defaultSession
  };

  if (typeof WebContentsView !== 'undefined') {
    tab.view = new WebContentsView({ webPreferences: webPrefs });
  } else {
    tab.view = new BrowserView({ webPreferences: webPrefs });
  }

  tab.isHibernated = false;
  setupWebContentsEvents(tab);
  tab.view.webContents.loadURL(formatUrlOrSearch(tab.url));
  notifyTabUpdated(tab);
}

// =============================================================================
// SPLIT SCREEN VIEW MANAGER
// =============================================================================
function toggleSplitView(secId) {
  if (isSplitViewActive && (!secId || secId === secondaryTabId)) {
    // Disable split
    if (secondaryTabId && tabs.has(secondaryTabId)) {
      detachTabView(tabs.get(secondaryTabId));
    }
    secondaryTabId = null;
    isSplitViewActive = false;
  } else {
    // Enable split
    if (secId && tabs.has(secId) && secId !== activeTabId) {
      secondaryTabId = secId;
    } else {
      const otherIds = Array.from(tabs.keys()).filter(id => id !== activeTabId);
      if (otherIds.length > 0) {
        secondaryTabId = otherIds[0];
      } else {
        secondaryTabId = createTab('staunt://newtab');
      }
    }
    isSplitViewActive = true;
    attachTabView(tabs.get(secondaryTabId));
  }

  updateLayoutBounds();

  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('split-view-updated', {
      isSplit: isSplitViewActive,
      secondaryTabId: secondaryTabId
    });
  }
}

// =============================================================================
// UTILITY URL FORMATTER & IPC CHANNELS
// =============================================================================
function formatUrlOrSearch(input) {
  const trimmed = (input || '').trim();
  const newTabUrl = 'file://' + path.join(__dirname, 'src', 'newtab.html').replace(/\\/g, '/');

  if (!trimmed || trimmed === 'staunt://newtab' || trimmed === 'about:newtab' || trimmed === 'about:blank') {
    return newTabUrl;
  }

  if (/^https?:\/\//i.test(trimmed) || /^file:\/\//i.test(trimmed)) {
    return trimmed;
  }

  const isDomain = /^([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(:\d+)?(\/.*)?$/i.test(trimmed) || /^localhost(:\d+)?/i.test(trimmed);
  if (isDomain) return 'https://' + trimmed;

  return `https://www.google.com/search?q=${encodeURIComponent(trimmed)}`;
}

// IPC Registrations
ipcMain.on('create-tab', (e, url, opts) => createTab(url, opts));
ipcMain.on('switch-tab', (e, tabId) => switchTab(tabId));
ipcMain.on('close-tab', (e, tabId) => closeTab(tabId));
ipcMain.on('toggle-split-view', (e, secId) => toggleSplitView(secId));

ipcMain.on('navigate-to', (e, url) => {
  const tab = tabs.get(activeTabId);
  if (tab && tab.view && tab.view.webContents) {
    tab.view.webContents.loadURL(formatUrlOrSearch(url));
  }
});

ipcMain.on('go-back', () => {
  const tab = tabs.get(activeTabId);
  if (tab && tab.view && tab.view.webContents && tab.view.webContents.canGoBack()) {
    tab.view.webContents.goBack();
  }
});

ipcMain.on('go-forward', () => {
  const tab = tabs.get(activeTabId);
  if (tab && tab.view && tab.view.webContents && tab.view.webContents.canGoForward()) {
    tab.view.webContents.goForward();
  }
});

ipcMain.on('reload-page', () => {
  const tab = tabs.get(activeTabId);
  if (tab && tab.view && tab.view.webContents) {
    tab.view.webContents.reload();
  }
});

ipcMain.on('toggle-mute-tab', (e, tabId) => {
  const targetId = tabId || activeTabId;
  const tab = tabs.get(targetId);
  if (tab && tab.view && tab.view.webContents) {
    tab.isMuted = !tab.isMuted;
    tab.view.webContents.setAudioMuted(tab.isMuted);
    notifyTabUpdated(tab);
  }
});

ipcMain.on('set-sidebar-state', (e, isCollapsed) => {
  isSidebarCollapsed = !!isCollapsed;
  updateLayoutBounds();
});

ipcMain.on('clear-browser-cache', () => {
  session.defaultSession.clearCache();
  session.defaultSession.clearStorageData();
  console.log('[CACHE] Browser cache and storage cleared successfully.');
});

// Native Window Controls
ipcMain.on('window-minimize', () => { if (mainWindow) mainWindow.minimize(); });
ipcMain.on('window-maximize', () => {
  if (mainWindow) {
    if (mainWindow.isMaximized()) mainWindow.unmaximize();
    else mainWindow.maximize();
  }
});
ipcMain.on('window-close', () => { if (mainWindow) mainWindow.close(); });
ipcMain.on('toggle-devtools', () => {
  const tab = tabs.get(activeTabId);
  if (tab && tab.view && tab.view.webContents) {
    tab.view.webContents.toggleDevTools();
  }
});

// App Lifecycle
app.whenReady().then(() => {
  createMainWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createMainWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
