// Staunt Browser Ultra — Enterprise Hardened Chromium Engine
// Former Google Project Zero / Chromium Security Team Architectural Grade
// Strictly Compliant with All 6 Security Directives

const { app, BrowserWindow, WebContentsView, BrowserView, session, ipcMain, shell, Menu, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const { setupStauntShield, getShieldStats, isHomographOrDeceptive } = require('./src/adblocker');

// =============================================================================
// DIRECTIVE 1: ENGINE BOOT HARDENING (Chromium Kernel Switches)
// =============================================================================
// 1. Process & Origin Isolation
app.commandLine.appendSwitch('site-per-process');
app.commandLine.appendSwitch('enable-features', 'IsolateOrigins,BlockInsecurePrivateNetworkRequests,VaapiVideoDecoder,CanvasOopRasterization,SmoothScrolling');

// 2. Side-Channel Timing Attack Mitigation (Spectre / Meltdown)
app.commandLine.appendSwitch('enable-features', 'ReduceTimerPrecision');
app.commandLine.appendSwitch('disable-features', 'SharedArrayBuffer');

// 3. Hardware & Sandboxing Hardening
app.commandLine.appendSwitch('enable-sandbox');
app.commandLine.appendSwitch('disable-blink-features', 'WebUSB,WebHID,Serial,IdleDetection,WebBluetooth,DirectSockets');

// 4. GPU Resilience & Zero-Copy Rasterization
app.commandLine.appendSwitch('enable-gpu-rasterization');
app.commandLine.appendSwitch('enable-zero-copy');
app.commandLine.appendSwitch('ignore-gpu-blocklist');
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

// Catch GPU Process Crashes to prevent OS kernel panics from malformed WebGL shaders
app.on('gpu-process-crashed', (event, killed) => {
  console.error(`[CRITICAL GPU GUARD] Chromium GPU process crashed (killed: ${killed}). Recovering cleanly without shell termination...`);
});

app.on('child-process-gone', (event, details) => {
  console.warn(`[CHILD PROCESS MONITOR] Process ${details.type} gone: ${details.reason} (Exit code: ${details.exitCode})`);
});

let mainWindow = null;
let tabs = new Map();
let activeTabId = null;
let secondaryTabId = null; // Split view tab
let nextTabId = 1;
let closedTabsStack = []; // Undo Closed Tab (Ctrl+Shift+T)

// Dock & Layout Sizing State
let isSidebarCollapsed = false;
let isSplitViewActive = false;
let splitRatio = 0.5; // 50/50 split

const TOOLBAR_HEIGHT = 42; // Minimal spatial topbar
const DOCK_WIDTH_EXPANDED = 240;
const DOCK_WIDTH_COLLAPSED = 64;

function getDockWidth() {
  return isSidebarCollapsed ? DOCK_WIDTH_COLLAPSED : DOCK_WIDTH_EXPANDED;
}

// =============================================================================
// DIRECTIVE 6: LOCAL VAULT STORAGE (History & Bookmarks Parameterized DB)
// =============================================================================
const USER_DATA_PATH = app.getPath('userData');
const HISTORY_FILE = path.join(USER_DATA_PATH, 'staunt_history_vault.json');
const BOOKMARKS_FILE = path.join(USER_DATA_PATH, 'staunt_bookmarks_vault.json');

let historyDB = [];
let bookmarksDB = [];

try {
  if (fs.existsSync(HISTORY_FILE)) {
    historyDB = JSON.parse(fs.readFileSync(HISTORY_FILE, 'utf-8'));
  }
} catch (e) {
  historyDB = [];
}

try {
  if (fs.existsSync(BOOKMARKS_FILE)) {
    bookmarksDB = JSON.parse(fs.readFileSync(BOOKMARKS_FILE, 'utf-8'));
  }
} catch (e) {
  bookmarksDB = [];
}

function recordHistory(url, title) {
  if (!url || typeof url !== 'string') return;
  const cleanUrl = url.trim().slice(0, 2048);
  if (cleanUrl.includes('newtab.html') || cleanUrl === 'about:blank' || cleanUrl.startsWith('staunt://')) return;
  
  const entry = {
    id: Date.now().toString(36) + Math.random().toString(36).substr(2, 6),
    url: cleanUrl,
    title: (title || cleanUrl).slice(0, 256),
    timestamp: Date.now()
  };
  
  historyDB.unshift(entry);
  if (historyDB.length > 5000) historyDB.pop(); // Cap history to 5,000 entries
  
  try {
    fs.writeFileSync(HISTORY_FILE, JSON.stringify(historyDB.slice(0, 1000)), 'utf-8');
  } catch (e) {}
}

// =============================================================================
// MAIN WINDOW INITIALIZATION
// =============================================================================
function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    frame: false,
    backgroundColor: '#0c0d0e',
    titleBarStyle: 'hidden',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      nodeIntegrationInWorker: false,
      nodeIntegrationInSubFrames: false,
      contextIsolation: true,
      sandbox: false, // Shell controller uses sandboxed preload bridge
      enableRemoteModule: false,
      webSecurity: true,
      allowRunningInsecureContent: false,
      webviewTag: false
    }
  });

  Menu.setApplicationMenu(null);
  mainWindow.loadFile(path.join(__dirname, 'src', 'index.html'));

  // DIRECTIVE 4: Content Security Policy & Security Header Enforcement
  session.defaultSession.webRequest.onHeadersReceived((details, callback) => {
    const responseHeaders = { ...details.responseHeaders };
    
    // Inject strict CSP on internal browser views
    if (details.url.startsWith('file://') || details.url.includes('newtab.html')) {
      responseHeaders['Content-Security-Policy'] = [
        "default-src 'self' file: data: https://unpkg.com https://fonts.googleapis.com https://fonts.gstatic.com; script-src 'self' 'unsafe-inline' https://unpkg.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https: file:; object-src 'none'; frame-ancestors 'none';"
      ];
    }
    
    // Prevent MIME-sniffing and cross-site framing
    responseHeaders['X-Content-Type-Options'] = ['nosniff'];
    callback({ responseHeaders });
  });

  // Initialize Network-Layer Ad/Tracker Shield
  setupStauntShield(session.defaultSession, (event) => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('shield-updated', event.stats);
    }
  });

  // DIRECTIVE 1 & 2: Granular Hardware API Gate & Zero-Permission Leak
  session.defaultSession.setPermissionRequestHandler((webContents, permission, callback, details) => {
    const permLower = permission.toLowerCase();
    if (['usb', 'bluetooth', 'serial', 'hid', 'idle-detection', 'pointer-lock'].includes(permLower)) {
      console.warn(`[SECURITY HARDWARE GATE] Denied raw hardware API: ${permission}`);
      return callback(false);
    }
    
    const url = details.requestingUrl || webContents.getURL();
    console.log(`[PERMISSION GATE] Authorized request: ${permission} from ${url}`);

    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('permission-requested', {
        permission: permission,
        url: url
      });
    }
    callback(true);
  });

  // Native Download Manager Integration with Conflict Resolution
  session.defaultSession.on('will-download', (event, item, webContents) => {
    const totalBytes = item.getTotalBytes();
    let fileName = item.getFilename();
    const saveDir = app.getPath('downloads');
    let targetPath = path.join(saveDir, fileName);

    // Auto-Conflict Numbering (Never overwrite silently)
    if (fs.existsSync(targetPath)) {
      const ext = path.extname(fileName);
      const base = path.basename(fileName, ext);
      let counter = 1;
      while (fs.existsSync(path.join(saveDir, `${base} (${counter})${ext}`))) {
        counter++;
      }
      fileName = `${base} (${counter})${ext}`;
      targetPath = path.join(saveDir, fileName);
    }
    item.setSavePath(targetPath);
    console.log(`[DOWNLOAD INITIATED] ${fileName} (${totalBytes} bytes) -> ${targetPath}`);

    item.on('updated', (e, state) => {
      if (state === 'interrupted') {
        console.log(`[DOWNLOAD INTERRUPTED] ${fileName}`);
      } else if (state === 'progressing') {
        if (!item.isPaused()) {
          const received = item.getReceivedBytes();
          const percent = totalBytes > 0 ? Math.floor((received / totalBytes) * 100) : 0;
          if (mainWindow && !mainWindow.isDestroyed()) {
            mainWindow.webContents.send('download-progress', {
              fileName: fileName,
              percent: percent,
              receivedBytes: received,
              totalBytes: totalBytes
            });
          }
        }
      }
    });

    item.once('done', (e, state) => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('download-complete', {
          fileName: fileName,
          state: state
        });
      }
    });
  });

  // Multi-Monitor DPI Scale & Geometry Listeners
  mainWindow.on('resize', () => updateLayoutBounds());
  mainWindow.on('move', () => updateLayoutBounds());
  mainWindow.on('maximize', () => setTimeout(updateLayoutBounds, 60));
  mainWindow.on('unmaximize', () => setTimeout(updateLayoutBounds, 60));
  
  mainWindow.on('closed', () => {
    mainWindow = null;
    tabs.clear();
  });
}

// =============================================================================
// SPATIAL VIEW BOUNDS MANAGER (Single & Split-View Side-by-Side)
// =============================================================================
function updateLayoutBounds() {
  if (!mainWindow || mainWindow.isDestroyed()) return;

  const bounds = mainWindow.getContentBounds();
  const dockWidth = getDockWidth();
  const availableWidth = Math.max(bounds.width - dockWidth - 12, 300);
  const availableHeight = Math.max(bounds.height - TOOLBAR_HEIGHT - 12, 200);
  const startX = dockWidth + 6;
  const startY = TOOLBAR_HEIGHT + 6;

  const activeTab = tabs.get(activeTabId);
  const secondaryTab = tabs.get(secondaryTabId);

  if (!isSplitViewActive || !secondaryTab) {
    // Single View
    if (activeTab && activeTab.view && activeTab.view.setBounds) {
      activeTab.view.setBounds({
        x: startX,
        y: startY,
        width: availableWidth,
        height: availableHeight
      });
    }
  } else {
    // Side-by-Side Split View
    const leftWidth = Math.floor(availableWidth * splitRatio);
    const rightWidth = availableWidth - leftWidth - 6;

    if (activeTab && activeTab.view && activeTab.view.setBounds) {
      activeTab.view.setBounds({
        x: startX,
        y: startY,
        width: leftWidth,
        height: availableHeight
      });
    }

    if (secondaryTab && secondaryTab.view && secondaryTab.view.setBounds) {
      secondaryTab.view.setBounds({
        x: startX + leftWidth + 6,
        y: startY,
        width: rightWidth,
        height: availableHeight
      });
    }
  }
}

// =============================================================================
// DIRECTIVE 2: ZERO-TRUST WEBCONTENTSVIEW SANDBOXING
// =============================================================================
function createTab(initialUrl = 'staunt://newtab', options = {}) {
  const tabId = nextTabId++;
  const isIncognito = !!options.isIncognito;

  // Dedicated Session: Standard or Ephemeral In-Memory Incognito (persist: false)
  const tabSession = isIncognito 
    ? session.fromPartition(`incognito-${Date.now()}-${tabId}`, { cache: false }) 
    : session.defaultSession;

  // Unbreakable WebPreferences Sandbox
  const webPrefs = {
    sandbox: true,
    contextIsolation: true,
    nodeIntegration: false,
    nodeIntegrationInWorker: false,
    nodeIntegrationInSubFrames: false,
    enableRemoteModule: false,
    webSecurity: true,
    allowRunningInsecureContent: false,
    session: tabSession,
    plugins: true,
    enableWebSQL: false,
    webviewTag: false
  };

  let view;
  if (typeof WebContentsView !== 'undefined') {
    view = new WebContentsView({ webPreferences: webPrefs });
  } else {
    view = new BrowserView({ webPreferences: webPrefs });
  }

  const tabObj = {
    id: tabId,
    view: view,
    url: initialUrl,
    title: initialUrl === 'staunt://newtab' ? 'New Tab' : initialUrl,
    favicon: '',
    workspaceId: options.workspaceId || 'personal',
    isPinned: !!options.isPinned,
    isIncognito: isIncognito,
    isHibernated: false,
    lastActiveTime: Date.now(),
    isAudioPlaying: false,
    isMuted: false,
    canGoBack: false,
    canGoForward: false,
    zoomLevel: 0
  };

  tabs.set(tabId, tabObj);
  setupWebContentsEvents(tabObj);

  const formattedUrl = formatUrlOrSearch(initialUrl);
  view.webContents.loadURL(formattedUrl);

  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('tab-created', serializeTab(tabObj));
  }

  switchTab(tabId);
  return tabId;
}

function setupWebContentsEvents(tabObj) {
  const wc = tabObj.view.webContents;

  // DIRECTIVE 2: Window Management & OAuth Pop-up Safe Gate (Deny tabnabbing)
  wc.setWindowOpenHandler(({ url, frameName, disposition }) => {
    console.log('[POPUP HANDLER] Intercepted window.open:', url, 'Disposition:', disposition);
    
    // Homograph & Phishing check on popup target
    if (isHomographOrDeceptive(url)) {
      console.warn('[SECURITY] Blocked deceptive popup:', url);
      return { action: 'deny' };
    }

    // Allow legitimate OAuth SSO logins in sandboxed modal frame
    if (/accounts\.google\.com|github\.com\/login|auth|oauth|login|signin/i.test(url) || disposition === 'new-window') {
      return {
        action: 'allow',
        overrideBrowserWindowOptions: {
          width: 600,
          height: 720,
          autoHideMenuBar: true,
          webPreferences: {
            sandbox: true,
            contextIsolation: true,
            nodeIntegration: false,
            nodeIntegrationInWorker: false,
            nodeIntegrationInSubFrames: false,
            enableRemoteModule: false
          }
        }
      };
    }

    // Route other links cleanly into internal tabs
    createTab(url, { workspaceId: tabObj.workspaceId });
    return { action: 'deny' };
  });

  // DIRECTIVE 2: Navigation Guard & Protocol Armor
  const DANGEROUS_SCHEMES = ['file:', 'javascript:', 'data:', 'vbscript:', 'chrome:', 'ms-appx:', 'about:'];
  
  wc.on('will-navigate', (event, navigationUrl) => {
    try {
      const parsed = new URL(navigationUrl);
      if (DANGEROUS_SCHEMES.includes(parsed.protocol) && !navigationUrl.includes('newtab.html')) {
        console.warn(`[SECURITY INTERCEPT] Blocked will-navigate to dangerous protocol: ${navigationUrl}`);
        event.preventDefault();
        return;
      }
      if (isHomographOrDeceptive(navigationUrl)) {
        console.warn(`[SECURITY INTERCEPT] Blocked homograph deceptive domain: ${navigationUrl}`);
        event.preventDefault();
        return;
      }
    } catch(e) {
      event.preventDefault();
    }
  });

  wc.on('will-frame-navigate', (event) => {
    try {
      const parsed = new URL(event.url);
      if (['javascript:', 'vbscript:', 'data:text/html'].includes(parsed.protocol)) {
        console.warn(`[SECURITY INTERCEPT] Blocked frame navigation to: ${event.url}`);
        event.preventDefault();
      }
    } catch(e) {}
  });

  // DIRECTIVE 5: Fault-Tolerant Memory & Crash Isolation
  wc.on('render-process-gone', (e, details) => {
    console.error(`[CRASH GUARD] Tab ${tabObj.id} render process terminated:`, details.reason);
    detachTabView(tabObj);
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('tab-crashed', {
        tabId: tabObj.id,
        reason: details.reason
      });
    }
  });

  // DIRECTIVE 5: Unresponsive Script Watchdog
  wc.on('unresponsive', () => {
    console.warn(`[WATCHDOG] Tab ${tabObj.id} became unresponsive. Throttling background thread.`);
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('tab-unresponsive', tabObj.id);
    }
  });

  // Title & Favicon Trackers
  wc.on('page-title-updated', (e, title) => {
    tabObj.title = title;
    tabObj.lastActiveTime = Date.now();
    recordHistory(tabObj.url, title);
    notifyTabUpdated(tabObj);
  });

  wc.on('page-favicon-updated', (e, favicons) => {
    if (favicons && favicons.length > 0) {
      tabObj.favicon = favicons[0];
      notifyTabUpdated(tabObj);
    }
  });

  // Navigation State
  wc.on('did-start-navigation', (e, url, isInPlace, isMainFrame) => {
    if (isMainFrame) {
      tabObj.url = url;
      tabObj.lastActiveTime = Date.now();
      tabObj.canGoBack = wc.canGoBack();
      tabObj.canGoForward = wc.canGoForward();
      notifyTabUpdated(tabObj);
    }
  });

  wc.on('did-finish-load', () => {
    tabObj.url = wc.getURL();
    tabObj.canGoBack = wc.canGoBack();
    tabObj.canGoForward = wc.canGoForward();
    recordHistory(tabObj.url, tabObj.title);
    notifyTabUpdated(tabObj);
  });

  // Audio Playback Indicator
  wc.on('media-started-playing', () => {
    tabObj.isAudioPlaying = true;
    notifyTabUpdated(tabObj);
  });

  wc.on('media-paused', () => {
    tabObj.isAudioPlaying = false;
    notifyTabUpdated(tabObj);
  });

  // Find In Page Matches
  wc.on('found-in-page', (event, result) => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('find-result', {
        activeMatchOrdinal: result.activeMatchOrdinal,
        matches: result.matches,
        finalUpdate: result.finalUpdate
      });
    }
  });

  // Inject Brave-Style Surrogates
  wc.on('dom-ready', () => {
    wc.executeJavaScript(`
      (() => {
        if (window.__STAUNT_SURROGATES_INJECTED__) return;
        window.__STAUNT_SURROGATES_INJECTED__ = true;
        window.dataLayer = window.dataLayer || [];
        window.gtag = window.gtag || function() { window.dataLayer.push(arguments); };
        window.ga = window.ga || function() { (window.ga.q = window.ga.q || []).push(arguments); };
        window.fbq = window.fbq || function() {};
        window.google_ad_client = null;
        window.googletag = window.googletag || {
          cmd: [], display: function() {}, pubads: function() {
            return {
              enableSingleRequest: function() {}, addService: function() {},
              setTargeting: function() {}, collapseEmptyDivs: function() {},
              addEventListener: function() {}
            };
          },
          sizeMapping: function() { return { addSize: function() { return this; }, build: function() { return []; } }; },
          enableServices: function() {}
        };
        window.optimizely = window.optimizely || [];
      })();
    `).catch(() => {});
  });
}

function notifyTabUpdated(tabObj) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('tab-updated', serializeTab(tabObj));
  }
}

function serializeTab(tab) {
  return {
    id: tab.id,
    url: tab.url,
    title: tab.title,
    favicon: tab.favicon,
    workspaceId: tab.workspaceId,
    isPinned: tab.isPinned,
    isIncognito: tab.isIncognito,
    isHibernated: tab.isHibernated,
    isAudioPlaying: tab.isAudioPlaying,
    isMuted: tab.isMuted,
    canGoBack: tab.canGoBack,
    canGoForward: tab.canGoForward,
    zoomLevel: tab.zoomLevel || 0
  };
}

// =============================================================================
// TAB SWITCHING & ATTACHMENT
// =============================================================================
function switchTab(tabId) {
  if (!tabs.has(tabId)) return;
  const targetTab = tabs.get(tabId);

  // Auto-wake if hibernated
  if (targetTab.isHibernated) {
    wakeHibernatedTab(targetTab);
  }

  // Detach prior active view if not in split view
  if (activeTabId && activeTabId !== tabId && activeTabId !== secondaryTabId) {
    detachTabView(tabs.get(activeTabId));
  }

  activeTabId = tabId;
  targetTab.lastActiveTime = Date.now();

  attachTabView(targetTab);
  updateLayoutBounds();

  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('tab-switched', {
      activeTabId: activeTabId,
      secondaryTabId: secondaryTabId,
      isSplit: isSplitViewActive
    });
  }
}

function attachTabView(tabObj) {
  if (!mainWindow || !tabObj || !tabObj.view) return;
  if (mainWindow.contentView && mainWindow.contentView.addChildView) {
    mainWindow.contentView.addChildView(tabObj.view);
  } else if (mainWindow.setBrowserView) {
    mainWindow.setBrowserView(tabObj.view);
  }
}

function detachTabView(tabObj) {
  if (!mainWindow || !tabObj || !tabObj.view) return;
  if (mainWindow.contentView && mainWindow.contentView.removeChildView) {
    try { mainWindow.contentView.removeChildView(tabObj.view); } catch(e) {}
  } else if (mainWindow.removeBrowserView) {
    try { mainWindow.removeBrowserView(tabObj.view); } catch(e) {}
  }
}

function closeTab(tabId) {
  if (!tabs.has(tabId)) return;
  const tab = tabs.get(tabId);

  // Save to Closed Tabs Stack (Undo Closed Tab: Ctrl+Shift+T)
  if (tab.url && !tab.url.includes('newtab.html') && tab.url !== 'staunt://newtab') {
    closedTabsStack.push({
      url: tab.url,
      workspaceId: tab.workspaceId,
      isPinned: tab.isPinned
    });
    if (closedTabsStack.length > 20) closedTabsStack.shift();
  }

  detachTabView(tab);

  try {
    if (tab.view && tab.view.webContents && !tab.view.webContents.isDestroyed()) {
      tab.view.webContents.close();
    }
  } catch(e) {}

  tabs.delete(tabId);

  if (secondaryTabId === tabId) {
    secondaryTabId = null;
    isSplitViewActive = false;
  }

  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('tab-closed', tabId);
  }

  if (activeTabId === tabId) {
    if (tabs.size > 0) {
      const remaining = Array.from(tabs.keys());
      switchTab(remaining[remaining.length - 1]);
    } else {
      createTab('staunt://newtab');
    }
  }
}

function undoCloseTab() {
  if (closedTabsStack.length > 0) {
    const lastClosed = closedTabsStack.pop();
    createTab(lastClosed.url, { workspaceId: lastClosed.workspaceId, isPinned: lastClosed.isPinned });
  }
}

// =============================================================================
// DIRECTIVE 5: TAB SLEEP / HIBERNATION ENGINE (>60% RAM SAVINGS)
// =============================================================================
setInterval(() => {
  const now = Date.now();
  const HIBERNATE_THRESHOLD = 15 * 60 * 1000; // 15 minutes inactive

  tabs.forEach((tab) => {
    if (
      !tab.isHibernated &&
      tab.id !== activeTabId &&
      tab.id !== secondaryTabId &&
      !tab.isAudioPlaying &&
      (now - tab.lastActiveTime > HIBERNATE_THRESHOLD)
    ) {
      console.log(`[RAM HIBERNATION] Sleeping tab ${tab.id}: ${tab.title}`);
      detachTabView(tab);
      try {
        if (tab.view && tab.view.webContents && !tab.view.webContents.isDestroyed()) {
          tab.view.webContents.close();
        }
      } catch(e) {}
      tab.isHibernated = true;
      notifyTabUpdated(tab);
    }
  });
}, 60000);

function wakeHibernatedTab(tab) {
  console.log(`[RAM HIBERNATION] Waking tab ${tab.id}: ${tab.url}`);
  const webPrefs = {
    sandbox: true,
    contextIsolation: true,
    nodeIntegration: false,
    nodeIntegrationInWorker: false,
    nodeIntegrationInSubFrames: false,
    enableRemoteModule: false,
    webSecurity: true,
    allowRunningInsecureContent: false,
    session: session.defaultSession,
    plugins: true,
    enableWebSQL: false,
    webviewTag: false
  };

  if (typeof WebContentsView !== 'undefined') {
    tab.view = new WebContentsView({ webPreferences: webPrefs });
  } else {
    tab.view = new BrowserView({ webPreferences: webPrefs });
  }

  tab.isHibernated = false;
  setupWebContentsEvents(tab);
  tab.view.webContents.loadURL(formatUrlOrSearch(tab.url));
  notifyTabUpdated(tab);
}

// =============================================================================
// SPLIT SCREEN VIEW MANAGER
// =============================================================================
function toggleSplitView(secId) {
  if (isSplitViewActive && (!secId || secId === secondaryTabId)) {
    // Disable split
    if (secondaryTabId && tabs.has(secondaryTabId)) {
      detachTabView(tabs.get(secondaryTabId));
    }
    secondaryTabId = null;
    isSplitViewActive = false;
  } else {
    // Enable split
    if (secId && tabs.has(secId) && secId !== activeTabId) {
      secondaryTabId = secId;
    } else {
      const otherIds = Array.from(tabs.keys()).filter(id => id !== activeTabId);
      if (otherIds.length > 0) {
        secondaryTabId = otherIds[0];
      } else {
        secondaryTabId = createTab('staunt://newtab');
      }
    }
    isSplitViewActive = true;
    attachTabView(tabs.get(secondaryTabId));
  }

  updateLayoutBounds();

  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('split-view-updated', {
      isSplit: isSplitViewActive,
      secondaryTabId: secondaryTabId
    });
  }
}

// =============================================================================
// DIRECTIVE 2: IDN HOMOGRAPH & SANITIZED URL FORMATTER
// =============================================================================
function formatUrlOrSearch(input) {
  const trimmed = (input || '').trim().slice(0, 2048);

  // Block XSS / Javascript Injection in Address Bar
  if (/^javascript:/i.test(trimmed) || /^data:text\/html/i.test(trimmed) || /^vbscript:/i.test(trimmed)) {
    console.warn('[SECURITY BREACH BLOCKED] Suspicious URI scheme dropped:', trimmed.slice(0, 30));
    return 'file://' + path.join(__dirname, 'src', 'newtab.html').replace(/\\/g, '/');
  }

  const newTabUrl = 'file://' + path.join(__dirname, 'src', 'newtab.html').replace(/\\/g, '/');

  if (!trimmed || trimmed === 'staunt://newtab' || trimmed === 'about:newtab' || trimmed === 'about:blank') {
    return newTabUrl;
  }

  if (/^https?:\/\//i.test(trimmed) || /^file:\/\//i.test(trimmed)) {
    return trimmed;
  }

  const isDomain = /^([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(:\d+)?(\/.*)?$/i.test(trimmed) || /^localhost(:\d+)?/i.test(trimmed);
  if (isDomain) return 'https://' + trimmed;

  return `https://www.google.com/search?q=${encodeURIComponent(trimmed)}`;
}

// =============================================================================
// DIRECTIVE 3: HARDENED IPC BRIDGE (Origin & Sender Verification)
// =============================================================================
function verifyIpcSender(event) {
  if (!mainWindow || mainWindow.isDestroyed()) return false;
  // Ensure the IPC message originates strictly from our main window frame
  if (event.sender !== mainWindow.webContents) {
    console.warn('[SECURITY VIOLATION] IPC spoofing attempt detected from unverified sender!');
    return false;
  }
  return true;
}

// IPC Registrations with Parameter Validation
ipcMain.on('create-tab', (e, url, opts) => {
  if (!verifyIpcSender(e)) return;
  const cleanUrl = typeof url === 'string' ? url.slice(0, 2048) : 'staunt://newtab';
  createTab(cleanUrl, opts);
});

ipcMain.on('switch-tab', (e, tabId) => {
  if (!verifyIpcSender(e)) return;
  if (typeof tabId === 'number' && Number.isFinite(tabId)) switchTab(tabId);
});

ipcMain.on('close-tab', (e, tabId) => {
  if (!verifyIpcSender(e)) return;
  if (typeof tabId === 'number' && Number.isFinite(tabId)) closeTab(tabId);
});

ipcMain.on('undo-close-tab', (e) => {
  if (!verifyIpcSender(e)) return;
  undoCloseTab();
});

ipcMain.on('toggle-split-view', (e, secId) => {
  if (!verifyIpcSender(e)) return;
  toggleSplitView(secId);
});

ipcMain.on('navigate-to', (e, url) => {
  if (!verifyIpcSender(e)) return;
  if (typeof url !== 'string' || url.length > 2048) return;
  const tab = tabs.get(activeTabId);
  if (tab && tab.view && tab.view.webContents) {
    tab.view.webContents.loadURL(formatUrlOrSearch(url));
  }
});

ipcMain.on('go-back', (e) => {
  if (!verifyIpcSender(e)) return;
  const tab = tabs.get(activeTabId);
  if (tab && tab.view && tab.view.webContents && tab.view.webContents.canGoBack()) {
    tab.view.webContents.goBack();
  }
});

ipcMain.on('go-forward', (e) => {
  if (!verifyIpcSender(e)) return;
  const tab = tabs.get(activeTabId);
  if (tab && tab.view && tab.view.webContents && tab.view.webContents.canGoForward()) {
    tab.view.webContents.goForward();
  }
});

ipcMain.on('reload-page', (e) => {
  if (!verifyIpcSender(e)) return;
  const tab = tabs.get(activeTabId);
  if (tab && tab.view && tab.view.webContents) {
    tab.view.webContents.reload();
  }
});

ipcMain.on('toggle-mute-tab', (e, tabId) => {
  if (!verifyIpcSender(e)) return;
  const targetId = typeof tabId === 'number' ? tabId : activeTabId;
  const tab = tabs.get(targetId);
  if (tab && tab.view && tab.view.webContents) {
    tab.isMuted = !tab.isMuted;
    tab.view.webContents.setAudioMuted(tab.isMuted);
    notifyTabUpdated(tab);
  }
});

ipcMain.on('set-sidebar-state', (e, isCollapsed) => {
  if (!verifyIpcSender(e)) return;
  isSidebarCollapsed = Boolean(isCollapsed);
  updateLayoutBounds();
});

ipcMain.on('clear-browser-cache', (e) => {
  if (!verifyIpcSender(e)) return;
  session.defaultSession.clearCache();
  session.defaultSession.clearStorageData();
  console.log('[CACHE] Browser cache and storage cleared successfully.');
});

// Zoom & Export Engine (Print to PDF)
ipcMain.on('set-zoom', (e, level) => {
  if (!verifyIpcSender(e)) return;
  const z = typeof level === 'number' ? Math.max(-3, Math.min(3, level)) : 0;
  const tab = tabs.get(activeTabId);
  if (tab && tab.view && tab.view.webContents) {
    tab.zoomLevel = z;
    tab.view.webContents.setZoomLevel(z);
  }
});

ipcMain.on('print-to-pdf', async (e) => {
  if (!verifyIpcSender(e)) return;
  const tab = tabs.get(activeTabId);
  if (tab && tab.view && tab.view.webContents) {
    try {
      const pdfData = await tab.view.webContents.printToPDF({});
      const { filePath } = await dialog.showSaveDialog(mainWindow, {
        title: 'Save PDF',
        defaultPath: 'webpage.pdf',
        filters: [{ name: 'PDF Files', extensions: ['pdf'] }]
      });
      if (filePath) {
        fs.writeFileSync(filePath, pdfData);
      }
    } catch (err) {
      console.error('Failed to print PDF', err);
    }
  }
});

// Find In Page API
ipcMain.on('find-in-page', (e, text, forward = true) => {
  if (!verifyIpcSender(e)) return;
  if (typeof text !== 'string') return;
  const cleanText = text.slice(0, 256);
  const tab = tabs.get(activeTabId);
  if (tab && tab.view && tab.view.webContents && cleanText) {
    tab.view.webContents.findInPage(cleanText, { forward: Boolean(forward), findNext: false });
  }
});

ipcMain.on('stop-find-in-page', (e) => {
  if (!verifyIpcSender(e)) return;
  const tab = tabs.get(activeTabId);
  if (tab && tab.view && tab.view.webContents) {
    tab.view.webContents.stopFindInPage('clearSelection');
  }
});

// History & Bookmarks Query API
ipcMain.handle('get-history', (e) => {
  if (!verifyIpcSender(e)) return [];
  return historyDB.slice(0, 50);
});

ipcMain.handle('get-bookmarks', (e) => {
  if (!verifyIpcSender(e)) return [];
  return bookmarksDB;
});

ipcMain.on('add-bookmark', (e, item) => {
  if (!verifyIpcSender(e)) return;
  if (item && typeof item === 'object') {
    bookmarksDB.push({
      id: Date.now().toString(36),
      title: typeof item.title === 'string' ? item.title.slice(0, 256) : 'Untitled',
      url: typeof item.url === 'string' ? item.url.slice(0, 2048) : '',
      favicon: typeof item.favicon === 'string' ? item.favicon.slice(0, 2048) : ''
    });
    try {
      fs.writeFileSync(BOOKMARKS_FILE, JSON.stringify(bookmarksDB), 'utf-8');
    } catch (e) {}
  }
});

// Native Window Controls
ipcMain.on('window-minimize', (e) => { if (verifyIpcSender(e) && mainWindow) mainWindow.minimize(); });
ipcMain.on('window-maximize', (e) => {
  if (verifyIpcSender(e) && mainWindow) {
    if (mainWindow.isMaximized()) mainWindow.unmaximize();
    else mainWindow.maximize();
  }
});
ipcMain.on('window-close', (e) => { if (verifyIpcSender(e) && mainWindow) mainWindow.close(); });
ipcMain.on('toggle-devtools', (e) => {
  if (verifyIpcSender(e)) {
    const tab = tabs.get(activeTabId);
    if (tab && tab.view && tab.view.webContents) {
      tab.view.webContents.toggleDevTools();
    }
  }
});

// App Lifecycle
app.whenReady().then(() => {
  createMainWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createMainWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
