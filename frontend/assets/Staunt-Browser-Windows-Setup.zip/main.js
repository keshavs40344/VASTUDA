// Staunt Browser Ultra — Main Process Engine
const { app, BrowserWindow, WebContentsView, BrowserView, session, ipcMain, shell } = require('electron');
const path = require('path');
const { setupStauntShield, getShieldStats } = require('./src/adblocker');

let mainWindow = null;
let tabs = new Map();
let activeTabId = null;
let nextTabId = 1;

const TOOLBAR_HEIGHT = 90; // Top tabbar + navbar height

function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1360,
    height: 860,
    minWidth: 800,
    minHeight: 600,
    frame: false, // Sleek frameless custom titlebar
    backgroundColor: '#0b0f19',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'src', 'index.html'));

  // Setup Staunt Shield network protection across all sessions
  setupStauntShield(session.defaultSession, (event) => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('shield-updated', event.stats);
    }
  });

  // Window resize handler to adjust active web view bounds
  mainWindow.on('resize', () => {
    updateActiveViewBounds();
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

let isDrawerOpen = false;
const DRAWER_WIDTH = 380;

function updateActiveViewBounds() {
  if (!mainWindow || !activeTabId) return;
  const tab = tabs.get(activeTabId);
  if (!tab) return;

  const bounds = mainWindow.getContentBounds();
  const viewWidth = Math.max(bounds.width - (isDrawerOpen ? DRAWER_WIDTH : 0), 200);
  const viewHeight = Math.max(bounds.height - TOOLBAR_HEIGHT, 100);

  if (tab.view.setBounds) {
    tab.view.setBounds({
      x: 0,
      y: TOOLBAR_HEIGHT,
      width: viewWidth,
      height: viewHeight
    });
  }
}

function createTab(initialUrl = 'staunt://newtab') {
  const tabId = nextTabId++;

  // Create isolated view using WebContentsView or BrowserView fallback
  let view;
  const webPrefs = {
    sandbox: true,
    contextIsolation: true,
    webSecurity: true,
    allowRunningInsecureContent: false
  };

  if (typeof WebContentsView !== 'undefined') {
    view = new WebContentsView({ webPreferences: webPrefs });
  } else {
    view = new BrowserView({ webPreferences: webPrefs });
  }

  const tabObj = {
    id: tabId,
    view: view,
    url: initialUrl,
    title: 'New Tab',
    favicon: ''
  };
  tabs.set(tabId, tabObj);

  const wc = view.webContents;

  // Track page title and favicons
  wc.on('page-title-updated', (e, title) => {
    tabObj.title = title;
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('tab-updated', {
        id: tabId,
        title: title,
        url: wc.getURL(),
        favicon: tabObj.favicon
      });
    }
  });

  wc.on('page-favicon-updated', (e, favicons) => {
    if (favicons && favicons.length > 0) {
      tabObj.favicon = favicons[0];
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('tab-updated', {
          id: tabId,
          title: tabObj.title,
          url: wc.getURL(),
          favicon: tabObj.favicon
        });
      }
    }
  });

  wc.on('did-start-navigation', (e, url, isInPlace, isMainFrame) => {
    if (isMainFrame) {
      tabObj.url = url;
      sendNavState(tabId);
    }
  });

  wc.on('did-finish-load', () => {
    tabObj.url = wc.getURL();
    sendNavState(tabId);
  });

  // Inject Brave-style surrogate scriptlets on early document creation to ensure 100% web app compatibility
  wc.on('dom-ready', () => {
    wc.executeJavaScript(`
      (() => {
        if (window.__STAUNT_SURROGATES_INJECTED__) return;
        window.__STAUNT_SURROGATES_INJECTED__ = true;
        window.dataLayer = window.dataLayer || [];
        window.gtag = window.gtag || function() { window.dataLayer.push(arguments); };
        window.ga = window.ga || function() { (window.ga.q = window.ga.q || []).push(arguments); };
        window.fbq = window.fbq || function() {};
        window.google_ad_client = null;
        window.googletag = window.googletag || {
          cmd: [],
          display: function() {},
          pubads: function() {
            return {
              enableSingleRequest: function() {},
              addService: function() {},
              setTargeting: function() {},
              collapseEmptyDivs: function() {},
              addEventListener: function() {}
            };
          },
          sizeMapping: function() {
            return { addSize: function() { return this; }, build: function() { return []; } };
          },
          enableServices: function() {}
        };
        window.optimizely = window.optimizely || [];
        window.dotcom = window.dotcom || { cmd: [], consent: { getConsent: function(){ return true; } } };
        window.dotcom.ads = window.dotcom.ads || { init: function(){}, display: function(){} };
        window.pdl = window.pdl || { requireConsent: 'v2' };
        window.tp = window.tp || [];
      })();
    `).catch(() => {});
  });

  // Media Sniffer for in-page videos & audio
  wc.session.webRequest.onResponseStarted((details) => {
    const u = details.url.toLowerCase();
    if (u.includes('.mp4') || u.includes('.m3u8') || u.includes('googlevideo.com/videoplayback') || u.includes('v.redd.it')) {
      if (mainWindow && !mainWindow.isDestroyed() && activeTabId === tabId) {
        mainWindow.webContents.send('media-detected', {
          tabId: tabId,
          url: wc.getURL(),
          mediaStreamUrl: details.url,
          title: tabObj.title
        });
      }
    }
  });

  // Format valid URL or Google search query
  const targetUrl = formatUrlOrSearch(initialUrl);
  wc.loadURL(targetUrl);

  // Notify renderer of tab creation
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('tab-created', {
      id: tabId,
      title: tabObj.title,
      url: targetUrl,
      favicon: tabObj.favicon
    });
  }

  switchTab(tabId);
  return tabId;
}

function switchTab(tabId) {
  if (!tabs.has(tabId)) return;
  const currentTab = tabs.get(activeTabId);
  const nextTab = tabs.get(tabId);

  // Detach current view
  if (currentTab && mainWindow) {
    if (mainWindow.contentView && mainWindow.contentView.removeChildView) {
      try { mainWindow.contentView.removeChildView(currentTab.view); } catch (e) {}
    } else if (mainWindow.removeBrowserView) {
      try { mainWindow.removeBrowserView(currentTab.view); } catch (e) {}
    }
  }

  activeTabId = tabId;

  // Attach next view
  if (mainWindow && nextTab) {
    if (mainWindow.contentView && mainWindow.contentView.addChildView) {
      mainWindow.contentView.addChildView(nextTab.view);
    } else if (mainWindow.setBrowserView) {
      mainWindow.setBrowserView(nextTab.view);
    }
    updateActiveViewBounds();
  }

  sendNavState(tabId);
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('tab-switched', tabId);
  }
}

function closeTab(tabId) {
  if (!tabs.has(tabId)) return;
  const closingTab = tabs.get(tabId);

  if (mainWindow) {
    if (mainWindow.contentView && mainWindow.contentView.removeChildView) {
      try { mainWindow.contentView.removeChildView(closingTab.view); } catch (e) {}
    } else if (mainWindow.removeBrowserView) {
      try { mainWindow.removeBrowserView(closingTab.view); } catch (e) {}
    }
  }

  // Destroy web contents to free RAM
  try {
    if (closingTab.view.webContents && !closingTab.view.webContents.isDestroyed()) {
      closingTab.view.webContents.close();
    }
  } catch (err) {}

  tabs.delete(tabId);

  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('tab-closed', tabId);
  }

  // If closed tab was active, switch to next available tab
  if (activeTabId === tabId) {
    if (tabs.size > 0) {
      const remainingIds = Array.from(tabs.keys());
      switchTab(remainingIds[remainingIds.length - 1]);
    } else {
      createTab('https://www.google.com');
    }
  }
}

function sendNavState(tabId) {
  if (!mainWindow || mainWindow.isDestroyed() || activeTabId !== tabId) return;
  const tab = tabs.get(tabId);
  if (!tab || !tab.view.webContents) return;

  const wc = tab.view.webContents;
  mainWindow.webContents.send('nav-state-changed', {
    canGoBack: wc.canGoBack(),
    canGoForward: wc.canGoForward(),
    url: wc.getURL()
  });
}

function formatUrlOrSearch(input) {
  const trimmed = (input || '').trim();
  const newTabUrl = 'file://' + path.join(__dirname, 'src', 'newtab.html').replace(/\\/g, '/');

  if (!trimmed || trimmed === 'staunt://newtab' || trimmed === 'about:newtab' || trimmed === 'about:blank') {
    return newTabUrl;
  }

  // Check if it's already a full protocol URL
  if (/^https?:\/\//i.test(trimmed) || /^file:\/\//i.test(trimmed)) {
    return trimmed;
  }

  // Check if domain-like (e.g. youtube.com, github.com, localhost:3000)
  const isDomain = /^([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(:\d+)?(\/.*)?$/i.test(trimmed) || /^localhost(:\d+)?/i.test(trimmed);
  if (isDomain) {
    return 'https://' + trimmed;
  }

  // Otherwise, default to high-speed Google Search
  return `https://www.google.com/search?q=${encodeURIComponent(trimmed)}`;
}

// IPC Handlers
ipcMain.on('create-tab', (e, url) => createTab(url));
ipcMain.on('switch-tab', (e, tabId) => switchTab(tabId));
ipcMain.on('close-tab', (e, tabId) => closeTab(tabId));

ipcMain.on('navigate-to', (e, url) => {
  const tab = tabs.get(activeTabId);
  if (tab && tab.view.webContents) {
    const formatted = formatUrlOrSearch(url);
    tab.view.webContents.loadURL(formatted);
  }
});

ipcMain.on('go-back', () => {
  const tab = tabs.get(activeTabId);
  if (tab && tab.view.webContents && tab.view.webContents.canGoBack()) {
    tab.view.webContents.goBack();
  }
});

ipcMain.on('go-forward', () => {
  const tab = tabs.get(activeTabId);
  if (tab && tab.view.webContents && tab.view.webContents.canGoForward()) {
    tab.view.webContents.goForward();
  }
});

ipcMain.on('reload-page', () => {
  const tab = tabs.get(activeTabId);
  if (tab && tab.view.webContents) {
    tab.view.webContents.reload();
  }
});

ipcMain.on('go-home', () => {
  const tab = tabs.get(activeTabId);
  if (tab && tab.view.webContents) {
    tab.view.webContents.loadURL('https://www.google.com');
  }
});

// Window Minimizing/Maximizing
ipcMain.on('window-minimize', () => { if (mainWindow) mainWindow.minimize(); });
ipcMain.on('window-maximize', () => {
  if (mainWindow) {
    if (mainWindow.isMaximized()) mainWindow.unmaximize();
    else mainWindow.maximize();
  }
});
ipcMain.on('window-close', () => { if (mainWindow) mainWindow.close(); });

// DevTools
ipcMain.on('toggle-devtools', () => {
  const tab = tabs.get(activeTabId);
  if (tab && tab.view.webContents) {
    tab.view.webContents.toggleDevTools();
  }
});

// Distraction-Free Reader Mode
ipcMain.on('toggle-reader-mode', () => {
  const tab = tabs.get(activeTabId);
  if (tab && tab.view.webContents) {
    tab.view.webContents.executeJavaScript(`
      (() => {
        const article = document.querySelector('article') || document.querySelector('main') || document.body;
        const text = article.innerHTML;
        const title = document.title;
        document.body.innerHTML = '<div style="max-width:740px; margin:40px auto; padding:20px; font-family:serif; line-height:1.8; font-size:18px; color:#111;">' +
          '<h1 style="margin-bottom:20px; font-size:32px; line-height:1.3;">' + title + '</h1>' + text + '</div>';
        document.body.style.backgroundColor = '#fdfbf7';
      })();
    `).catch(() => {});
  }
});

// Media Sniffer Download
ipcMain.on('download-media', (e, mediaUrl) => {
  shell.openExternal(`https://web-production-2ac2a.up.railway.app/tools/media-downloader`);
});

// AI Drawer Toggle Bounds Sync
ipcMain.on('set-drawer-state', (e, isOpen) => {
  isDrawerOpen = !!isOpen;
  updateActiveViewBounds();
});

app.whenReady().then(() => {
  createMainWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createMainWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
