/**
 * Staunt Web-Core Reverse-Proxy & Gateway Server
 * Complete, zero-placeholder Node.js/Express in-process proxy gateway
 * Strips frame-blocking headers (X-Frame-Options, CSP frame-ancestors)
 * Enables seamless in-browser execution on Railway, Render, VPS, or local environments.
 */

const express = require('express');
const cors = require('cors');
const path = require('path');
const http = require('http');
const { createProxyMiddleware, responseInterceptor } = require('http-proxy-middleware');

const app = express();
const PORT = process.env.PORT || 3000;

// 1. Enable Global CORS
app.use(cors({
  origin: '*',
  methods: ['GET', 'HEAD', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['*'],
  exposedHeaders: ['*']
}));

// Helper: Normalize URL to ensure valid protocol
function normalizeTargetUrl(raw) {
  if (!raw) return null;
  let urlStr = raw.trim();
  if (!/^https?:\/\//i.test(urlStr)) {
    urlStr = 'https://' + urlStr;
  }
  return urlStr;
}

// 2. Gateway Proxy Router: /gateway?url=<TARGET_URL>
const gatewayProxy = createProxyMiddleware({
  router: (req) => {
    const rawTarget = req.query.url;
    const resolved = normalizeTargetUrl(rawTarget);
    if (!resolved) {
      throw new Error('Invalid target URL specified');
    }
    return resolved;
  },
  changeOrigin: true,
  ws: true,
  followRedirects: true,
  autoRewrite: true,
  selfHandleResponse: true, // Allows inspecting and transforming HTML content

  on: {
    proxyReq: (proxyReq, req, res) => {
      // Impersonate modern Chrome on macOS/Windows desktop
      proxyReq.setHeader(
        'User-Agent',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
      );
      proxyReq.setHeader('Accept-Language', 'en-US,en;q=0.9');

      // Forward target origin host
      try {
        const rawTarget = req.query.url;
        const targetObj = new URL(normalizeTargetUrl(rawTarget));
        proxyReq.setHeader('Host', targetObj.host);
      } catch (e) {}
    },

    proxyRes: responseInterceptor(async (responseBuffer, proxyRes, req, res) => {
      // 1. Strip restrictive frame-blocking and isolation headers
      delete proxyRes.headers['x-frame-options'];
      delete proxyRes.headers['content-security-policy'];
      delete proxyRes.headers['content-security-policy-report-only'];
      delete proxyRes.headers['frame-options'];
      delete proxyRes.headers['cross-origin-opener-policy'];
      delete proxyRes.headers['cross-origin-embedder-policy'];
      delete proxyRes.headers['cross-origin-resource-policy'];

      res.removeHeader('x-frame-options');
      res.removeHeader('content-security-policy');
      res.removeHeader('frame-options');

      // 2. Inject unrestricted CORS & framing headers
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Access-Control-Allow-Methods', 'GET, HEAD, POST, PUT, DELETE, OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', '*');
      res.setHeader('X-Frame-Options', 'ALLOWALL');

      const contentType = proxyRes.headers['content-type'] || '';
      
      // 3. For HTML documents, inject <base> tag and navigation click interceptor
      if (contentType.includes('text/html')) {
        try {
          const rawTarget = req.query.url;
          const targetUrl = normalizeTargetUrl(rawTarget);
          let html = responseBuffer.toString('utf8');

          // Inject <base href="..."> if not already present
          const baseInjection = `<base href="${targetUrl}">`;
          const navigationInterceptor = `
            <script>
              (function() {
                // Intercept in-page link clicks to route back to Staunt Gateway
                document.addEventListener('click', function(e) {
                  const anchor = e.target.closest('a');
                  if (anchor && anchor.href && !anchor.href.startsWith('javascript:')) {
                    e.preventDefault();
                    if (window.parent && window.parent !== window) {
                      window.parent.postMessage({ type: 'STAUNT_NAVIGATE', url: anchor.href }, '*');
                    } else {
                      window.location.href = '/gateway?url=' + encodeURIComponent(anchor.href);
                    }
                  }
                }, true);
              })();
            </script>
          `;

          if (/<head[^>]*>/i.test(html)) {
            html = html.replace(/<head[^>]*>/i, (match) => match + '\n' + baseInjection);
          } else {
            html = baseInjection + '\n' + html;
          }

          if (/<body[^>]*>/i.test(html)) {
            html = html.replace(/<body[^>]*>/i, (match) => match + '\n' + navigationInterceptor);
          } else {
            html = html + '\n' + navigationInterceptor;
          }

          return html;
        } catch (err) {
          console.error('[GATEWAY TRANSFORMATION ERROR]:', err);
        }
      }

      return responseBuffer;
    }),

    error: (err, req, res) => {
      console.error('[GATEWAY PROXY ERROR]:', err.message);
      if (!res.headersSent) {
        res.status(502).json({
          status: 'error',
          code: 'BAD_GATEWAY',
          message: 'Unable to connect to target destination via Staunt Web Gateway.',
          details: err.message
        });
      }
    }
  }
});

// Register Gateway route
app.use('/gateway', gatewayProxy);

// 3. Static Asset Hosting
const publicDir = path.join(__dirname, 'src');
app.use(express.static(publicDir, {
  maxAge: '1d',
  setHeaders: (res, path) => {
    if (path.endsWith('.html')) {
      res.setHeader('Cache-Control', 'no-cache');
    }
  }
}));

// Route root to index.html
app.get('/', (req, res) => {
  res.sendFile(path.join(publicDir, 'index.html'));
});

// Route /tools/staunt-browser to index.html for platform compatibility
app.get('/tools/staunt-browser', (req, res) => {
  res.sendFile(path.join(publicDir, 'index.html'));
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    service: 'Staunt Web-Core Gateway',
    timestamp: Date.now()
  });
});

// 4. Create HTTP & WebSocket Server
const server = http.createServer(app);

// Handle WebSockets upgrade
server.on('upgrade', (req, socket, head) => {
  if (req.url.startsWith('/gateway')) {
    gatewayProxy.upgrade(req, socket, head);
  }
});

// Start listening
server.listen(PORT, '0.0.0.0', () => {
  console.log(`[STAUNT CORE] Web Gateway listening on port ${PORT}`);
  console.log(`[STAUNT CORE] Ready on http://localhost:${PORT}`);
});

module.exports = app;
