
const { app, BrowserWindow, WebContentsView } = require('electron');
const path = require('path');

app.whenReady().then(() => {
  const win = new BrowserWindow({ width: 1200, height: 800, frame: false, show: false });
  const view = new WebContentsView();
  win.contentView.addChildView(view);
  const bounds = win.getContentBounds();
  view.setBounds({ x: 0, y: 44, width: bounds.width, height: bounds.height - 44 });
  const finalBounds = view.getBounds();
  console.log('Final bounds:', JSON.stringify(finalBounds));
  if (finalBounds.width === bounds.width && finalBounds.height === bounds.height - 44 && finalBounds.y === 44) {
    console.log('GEOMETRY_VERIFIED_SUCCESS');
  } else {
    console.error('GEOMETRY_MISMATCH');
  }
  app.quit();
});
