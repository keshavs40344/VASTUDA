const { app, BrowserWindow, WebContentsView, BrowserView } = require('electron');

app.whenReady().then(() => {
  console.log("ELECTRON APP READY!");
  const win = new BrowserWindow({ width: 800, height: 600, show: false });
  console.log("has contentView:", !!win.contentView);
  console.log("has setBrowserView:", typeof win.setBrowserView);
  if (win.contentView && typeof WebContentsView !== 'undefined') {
    const view = new WebContentsView();
    win.contentView.addChildView(view);
    view.setBounds({ x: 0, y: 0, width: 400, height: 400 });
    console.log("WebContentsView setBounds SUCCESS!");
  } else {
    console.log("WebContentsView not available, checking BrowserView");
    const bv = new BrowserView();
    win.setBrowserView(bv);
    bv.setBounds({ x: 0, y: 0, width: 400, height: 400 });
    console.log("BrowserView setBounds SUCCESS!");
  }
  process.exit(0);
});
