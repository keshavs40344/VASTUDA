// Staunt Shield — Aggressive In-Engine Ad & Tracker Blocker
// High-performance domain pattern matching & telemetry firewall

const BLOCKED_PATTERNS = [
  // Major Ad Networks
  '*://*.doubleclick.net/*',
  '*://*.googlesyndication.com/*',
  '*://*.googleadservices.com/*',
  '*://*.adservice.google.*/*',
  '*://*.adnxs.com/*',
  '*://*.rubiconproject.com/*',
  '*://*.criteo.com/*',
  '*://*.criteo.net/*',
  '*://*.outbrain.com/*',
  '*://*.taboola.com/*',
  '*://*.popads.net/*',
  '*://*.propellerads.com/*',
  '*://*.media.net/*',
  '*://*.pubmatic.com/*',
  '*://*.casalemedia.com/*',
  '*://*.bidswitch.net/*',
  '*://*.adroll.com/*',
  '*://*.scorecardresearch.com/*',
  '*://*.quantserve.com/*',
  '*://*.zedo.com/*',
  '*://*.adform.net/*',
  '*://*.adtechus.com/*',
  '*://*.moatads.com/*',
  '*://*.inmobi.com/*',
  '*://*.smartadserver.com/*',
  '*://*.exponential.com/*',
  '*://*.advertising.com/*',

  // Trackers & Telemetry Beacons
  '*://*.google-analytics.com/*',
  '*://*.analytics.google.com/*',
  '*://*.hotjar.com/*',
  '*://*.mouseflow.com/*',
  '*://*.crazyegg.com/*',
  '*://*.fullstory.com/*',
  '*://*.segment.io/*',
  '*://*.segment.com/*',
  '*://*.mixpanel.com/*',
  '*://*.optimizely.com/*',
  '*://*.clarity.ms/*',
  '*://*.facebook.net/*/fbevents.js*',
  '*://*.connect.facebook.net/*/sdk.js*',
  '*://*.ads-twitter.com/*',
  '*://*.analytics.twitter.com/*',
  '*://*.telemetry.*/*',
  '*://*.metrics.*/*',

  // YouTube Prerolls & Ad Pods
  '*://*.youtube.com/api/stats/ads*',
  '*://*.youtube.com/pagead/*',
  '*://*.youtube.com/ptracking*',
  '*://*.googlevideo.com/videoplayback*&adformat=*',
  '*://*.googlevideo.com/videoplayback*&oad=*',

  // Crypto Miners
  '*://*.coinhive.com/*',
  '*://*.crypto-loot.com/*',
  '*://*.coin-have.com/*',
  '*://*.jsecoin.com/*'
];

let blockedStats = {
  totalBlocked: 0,
  trackersBlocked: 0,
  adsBlocked: 0,
  bandwidthSavedMB: 0.0
};

function setupStauntShield(ses, onBlockedCallback) {
  ses.webRequest.onBeforeRequest({ urls: BLOCKED_PATTERNS }, (details, callback) => {
    blockedStats.totalBlocked++;
    if (details.url.includes('analytics') || details.url.includes('metric') || details.url.includes('telemetry') || details.url.includes('fbevents')) {
      blockedStats.trackersBlocked++;
    } else {
      blockedStats.adsBlocked++;
    }
    // Approx 150KB saved per blocked script/ad request
    blockedStats.bandwidthSavedMB += 0.15;

    if (onBlockedCallback) {
      onBlockedCallback({
        url: details.url,
        stats: { ...blockedStats, bandwidthSavedMB: Number(blockedStats.bandwidthSavedMB.toFixed(2)) }
      });
    }

    callback({ cancel: true });
  });

  // Strip Tracking Referrers and Headers
  ses.webRequest.onBeforeSendHeaders((details, callback) => {
    const headers = { ...details.requestHeaders };
    // Remove UTM & Click tracking
    delete headers['X-Client-Data'];
    callback({ requestHeaders: headers });
  });
}

function getShieldStats() {
  return { ...blockedStats, bandwidthSavedMB: Number(blockedStats.bandwidthSavedMB.toFixed(2)) };
}

function resetShieldStats() {
  blockedStats = { totalBlocked: 0, trackersBlocked: 0, adsBlocked: 0, bandwidthSavedMB: 0.0 };
}

module.exports = {
  setupStauntShield,
  getShieldStats,
  resetShieldStats,
  BLOCKED_PATTERNS
};
