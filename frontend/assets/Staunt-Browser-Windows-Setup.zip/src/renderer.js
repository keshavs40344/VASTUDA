// Safari Desktop Controller & Native Omnibox Gateway
let tabs = new Map();
let activeTabId = null;
let secondaryTabId = null;
let isOverviewOpen = false;

document.addEventListener('DOMContentLoaded', () => {
  const btnWinClose = document.getElementById('btnWinClose');
  const btnWinMin = document.getElementById('btnWinMin');
  const btnWinMax = document.getElementById('btnWinMax');

  const btnBack = document.getElementById('btnBack');
  const btnForward = document.getElementById('btnForward');
  const btnReload = document.getElementById('btnReload');

  const omniboxCapsule = document.getElementById('omniboxCapsule');
  const omniboxDisplay = document.getElementById('omniboxDisplay');
  const omniboxInput = document.getElementById('omniboxInput');

  const btnShare = document.getElementById('btnShare');
  const btnNewTab = document.getElementById('btnNewTab');
  const btnTabOverview = document.getElementById('btnTabOverview');
  const btnCloseOverview = document.getElementById('btnCloseOverview');

  const tabOverviewOverlay = document.getElementById('tabOverviewOverlay');
  const overviewGrid = document.getElementById('overviewGrid');

  // Traffic Lights Window Controls
  btnWinClose.addEventListener('click', () => window.stauntAPI.closeWindow());
  btnWinMin.addEventListener('click', () => window.stauntAPI.minimizeWindow());
  btnWinMax.addEventListener('click', () => window.stauntAPI.maximizeWindow());

  // Navigation
  btnBack.addEventListener('click', () => window.stauntAPI.goBack());
  btnForward.addEventListener('click', () => window.stauntAPI.goForward());
  btnReload.addEventListener('click', () => window.stauntAPI.reload());

  // New Tab & Share
  btnNewTab.addEventListener('click', () => {
    closeOverview();
    window.stauntAPI.createTab('staunt://newtab');
  });

  btnShare.addEventListener('click', () => {
    const activeTab = tabs.get(activeTabId);
    if (activeTab && activeTab.url && navigator.clipboard) {
      navigator.clipboard.writeText(activeTab.url);
      const originalText = omniboxDisplay.textContent;
      omniboxDisplay.textContent = 'Link Copied to Clipboard';
      setTimeout(() => { omniboxDisplay.textContent = originalText; }, 1800);
    }
  });

  // Tab Overview Toggle
  btnTabOverview.addEventListener('click', toggleOverview);
  btnCloseOverview.addEventListener('click', closeOverview);

  // Omnibox Interaction: Pure Domain Display <-> Instant Input
  omniboxCapsule.addEventListener('click', () => {
    activateOmnibox();
  });

  omniboxInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      submitOmnibox(omniboxInput.value.trim());
    } else if (e.key === 'Escape') {
      deactivateOmnibox();
    }
  });

  omniboxInput.addEventListener('blur', () => {
    setTimeout(deactivateOmnibox, 150);
  });

  function activateOmnibox() {
    omniboxCapsule.classList.add('focused');
    omniboxDisplay.classList.add('hidden');
    omniboxInput.classList.remove('hidden');

    const cur = tabs.get(activeTabId);
    if (cur && !cur.url.includes('newtab.html') && cur.url !== 'staunt://newtab') {
      omniboxInput.value = cur.url;
    } else {
      omniboxInput.value = '';
    }

    omniboxInput.focus();
    omniboxInput.select();
  }

  function deactivateOmnibox() {
    omniboxCapsule.classList.remove('focused');
    omniboxInput.classList.add('hidden');
    omniboxDisplay.classList.remove('hidden');
    const cur = tabs.get(activeTabId);
    if (cur) updateOmniboxDisplay(cur);
  }

  function submitOmnibox(val) {
    deactivateOmnibox();
    if (!val) return;
    window.stauntAPI.navigate(val);
  }

  function updateOmniboxDisplay(tab) {
    if (!tab || !tab.url || tab.url.includes('newtab.html') || tab.url === 'staunt://newtab') {
      omniboxDisplay.textContent = 'Search or enter website name';
      return;
    }

    try {
      const u = new URL(tab.url);
      // Display clean domain like Safari
      omniboxDisplay.textContent = u.hostname.replace(/^www\./, '');
    } catch(e) {
      omniboxDisplay.textContent = tab.url;
    }
  }

  // Tab Overview Grid Handling
  function toggleOverview() {
    isOverviewOpen = !isOverviewOpen;
    if (isOverviewOpen) {
      renderOverviewGrid();
      tabOverviewOverlay.classList.remove('hidden');
    } else {
      closeOverview();
    }
  }

  function closeOverview() {
    isOverviewOpen = false;
    tabOverviewOverlay.classList.add('hidden');
  }

  function renderOverviewGrid() {
    overviewGrid.innerHTML = '';
    tabs.forEach((tab) => {
      const card = document.createElement('div');
      card.className = `tab-card ${tab.id === activeTabId ? 'active' : ''}`;
      
      let domain = 'Start Page';
      try {
        if (!tab.url.includes('newtab.html') && tab.url !== 'staunt://newtab') {
          domain = new URL(tab.url).hostname.replace(/^www\./, '');
        }
      } catch(e) {}

      card.innerHTML = `
        <div class="tab-card-header">
          <div class="tab-card-info">
            <img class="tab-card-favicon" src="${tab.favicon || 'https://www.google.com/favicon.ico'}" onerror="this.src='https://www.google.com/favicon.ico'" />
            <span class="tab-card-title">${tab.title || domain}</span>
          </div>
          <button class="tab-card-close" title="Close Tab">&times;</button>
        </div>
        <div class="tab-card-body">
          <span>${domain}</span>
        </div>
      `;

      card.querySelector('.tab-card-close').addEventListener('click', (e) => {
        e.stopPropagation();
        window.stauntAPI.closeTab(tab.id);
      });

      card.addEventListener('click', () => {
        window.stauntAPI.switchTab(tab.id);
        closeOverview();
      });

      overviewGrid.appendChild(card);
    });
  }

  // Keyboard Shortcuts (Safari Native)
  window.addEventListener('keydown', (e) => {
    const isMeta = e.metaKey || e.ctrlKey;

    if (isMeta && e.key.toLowerCase() === 'l') {
      e.preventDefault();
      activateOmnibox();
    } else if (isMeta && e.key.toLowerCase() === 't') {
      e.preventDefault();
      closeOverview();
      window.stauntAPI.createTab('staunt://newtab');
    } else if (isMeta && e.key.toLowerCase() === 'w') {
      e.preventDefault();
      if (activeTabId) window.stauntAPI.closeTab(activeTabId);
    } else if (isMeta && e.shiftKey && e.key.toLowerCase() === 't') {
      e.preventDefault();
      window.stauntAPI.undoCloseTab();
    } else if (isMeta && e.key.toLowerCase() === 'r') {
      e.preventDefault();
      window.stauntAPI.reload();
    } else if (isMeta && e.key === '\\') {
      e.preventDefault();
      toggleOverview();
    } else if (isMeta && e.key.toLowerCase() === 'f') {
      e.preventDefault();
      const findBar = document.getElementById('findBar');
      findBar.classList.remove('hidden');
      const fIn = document.getElementById('findInput');
      fIn.focus();
      fIn.select();
    }
  });

  // Find In Page Handling
  const findBar = document.getElementById('findBar');
  const findInput = document.getElementById('findInput');
  const findMatches = document.getElementById('findMatches');
  document.getElementById('btnFindClose').addEventListener('click', () => {
    findBar.classList.add('hidden');
    window.stauntAPI.stopFindInPage();
  });
  document.getElementById('btnFindNext').addEventListener('click', () => {
    if (findInput.value) window.stauntAPI.findInPage(findInput.value, true);
  });
  document.getElementById('btnFindPrev').addEventListener('click', () => {
    if (findInput.value) window.stauntAPI.findInPage(findInput.value, false);
  });
  findInput.addEventListener('input', () => {
    if (findInput.value) window.stauntAPI.findInPage(findInput.value, true);
    else { window.stauntAPI.stopFindInPage(); findMatches.textContent = '0/0'; }
  });
  findInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') window.stauntAPI.findInPage(findInput.value, !e.shiftKey);
    else if (e.key === 'Escape') { findBar.classList.add('hidden'); window.stauntAPI.stopFindInPage(); }
  });

  // IPC Event Receivers
  window.stauntAPI.onTabCreated((tab) => {
    tabs.set(tab.id, tab);
    if (isOverviewOpen) renderOverviewGrid();
  });

  window.stauntAPI.onTabUpdated((tab) => {
    tabs.set(tab.id, tab);
    if (activeTabId === tab.id) updateOmniboxDisplay(tab);
    if (isOverviewOpen) renderOverviewGrid();
  });

  window.stauntAPI.onTabClosed((tabId) => {
    tabs.delete(tabId);
    if (isOverviewOpen) renderOverviewGrid();
  });

  window.stauntAPI.onTabSwitched((data) => {
    activeTabId = data.activeTabId;
    secondaryTabId = data.secondaryTabId;
    const cur = tabs.get(activeTabId);
    if (cur) updateOmniboxDisplay(cur);
    if (isOverviewOpen) renderOverviewGrid();
  });

  window.stauntAPI.onFindResult((res) => {
    findMatches.textContent = `${res.activeMatchOrdinal}/${res.matches}`;
  });

  // Start with clean initial tab
  window.stauntAPI.createTab('staunt://newtab');
});
