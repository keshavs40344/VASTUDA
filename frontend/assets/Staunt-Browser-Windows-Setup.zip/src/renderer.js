// Staunt Browser Ultra — Renderer Controller

let activeTabId = null;
let tabs = new Map();
let detectedMediaUrl = null;

// Initialize Lucide Icons
function refreshIcons() {
  if (window.lucide) {
    window.lucide.createIcons();
  }
}

document.addEventListener('DOMContentLoaded', () => {
  refreshIcons();

  // Window Controls
  document.getElementById('winMin').addEventListener('click', () => window.stauntAPI.minimizeWindow());
  document.getElementById('winMax').addEventListener('click', () => window.stauntAPI.maximizeWindow());
  document.getElementById('winClose').addEventListener('click', () => window.stauntAPI.closeWindow());

  // New Tab Button
  document.getElementById('btnNewTab').addEventListener('click', () => {
    window.stauntAPI.createTab('https://www.google.com');
  });

  // Navigation Buttons
  document.getElementById('btnBack').addEventListener('click', () => window.stauntAPI.goBack());
  document.getElementById('btnForward').addEventListener('click', () => window.stauntAPI.goForward());
  document.getElementById('btnReload').addEventListener('click', () => window.stauntAPI.reload());
  document.getElementById('btnHome').addEventListener('click', () => window.stauntAPI.goHome());

  // DevTools
  document.getElementById('btnDevTools').addEventListener('click', () => window.stauntAPI.toggleDevTools());

  // Reader Mode
  document.getElementById('btnReaderMode').addEventListener('click', () => window.stauntAPI.toggleReaderMode());

  // RAM Optimizer Notification
  document.getElementById('btnRamOptimizer').addEventListener('click', () => {
    alert("⚡ Staunt RAM Optimizer Active: Inactive background tabs put to sleep. RAM consumption minimized!");
  });

  // Omnibox Navigation
  const omnibox = document.getElementById('omniboxInput');
  omnibox.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const query = omnibox.value.trim();
      if (query) {
        window.stauntAPI.navigate(query);
      }
    }
  });

  omnibox.addEventListener('focus', () => {
    omnibox.select();
  });

  // Shield Popover Toggle
  const shieldBtn = document.getElementById('shieldBadgeBtn');
  const shieldPopover = document.getElementById('shieldPopover');
  shieldBtn.addEventListener('click', () => {
    shieldPopover.classList.toggle('hidden');
  });
  document.getElementById('btnCloseShieldPopover').addEventListener('click', () => {
    shieldPopover.classList.add('hidden');
  });

  // AI Drawer Toggle
  const aiBtn = document.getElementById('aiSidebarBtn');
  const aiDrawer = document.getElementById('aiDrawer');
  aiBtn.addEventListener('click', () => {
    aiDrawer.classList.toggle('hidden');
    const isOpen = !aiDrawer.classList.contains('hidden');
    window.stauntAPI.setDrawerState(isOpen);
  });
  document.getElementById('btnCloseAiDrawer').addEventListener('click', () => {
    aiDrawer.classList.add('hidden');
    window.stauntAPI.setDrawerState(false);
  });

  // AI Chat Input
  document.getElementById('aiSendBtn').addEventListener('click', sendAIMessage);
  document.getElementById('aiUserInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') sendAIMessage();
  });

  // Media Sniffer Button
  document.getElementById('mediaSnifferBtn').addEventListener('click', () => {
    if (detectedMediaUrl) {
      window.stauntAPI.downloadMedia(detectedMediaUrl);
    } else {
      const curUrl = omnibox.value;
      window.stauntAPI.downloadMedia(curUrl);
    }
  });

  // Bookmark Button
  const btnBookmark = document.getElementById('btnBookmark');
  if (btnBookmark) {
    btnBookmark.addEventListener('click', () => {
      const url = omnibox.value;
      if (!url) return;
      let bms = JSON.parse(localStorage.getItem('staunt_desktop_bms') || '[]');
      const idx = bms.findIndex(b => b.url === url);
      if (idx >= 0) {
        bms.splice(idx, 1);
        btnBookmark.style.color = '';
      } else {
        bms.push({ url, title: url, timestamp: Date.now() });
        btnBookmark.style.color = '#fbbf24';
      }
      localStorage.setItem('staunt_desktop_bms', JSON.stringify(bms));
    });
  }

  // Setup IPC Event Listeners from Main Process
  window.stauntAPI.onTabCreated(handleTabCreated);
  window.stauntAPI.onTabUpdated(handleTabUpdated);
  window.stauntAPI.onTabClosed(handleTabClosed);
  window.stauntAPI.onTabSwitched(handleTabSwitched);
  window.stauntAPI.onShieldUpdated(handleShieldUpdated);
  window.stauntAPI.onMediaDetected(handleMediaDetected);
  window.stauntAPI.onNavStateChanged(handleNavStateChanged);

  // Create initial tab
  window.stauntAPI.createTab('staunt://newtab');
});

// Tab Management
function handleTabCreated(tabData) {
  tabs.set(tabData.id, tabData);
  renderTabElement(tabData);
  setActiveTab(tabData.id);
}

function renderTabElement(tabData) {
  const container = document.getElementById('tabsContainer');
  const tabEl = document.createElement('div');
  tabEl.className = 'tab';
  tabEl.id = `tab-${tabData.id}`;
  tabEl.innerHTML = `
    <img src="${tabData.favicon || 'https://www.google.com/favicon.ico'}" class="tab-favicon" onerror="this.src='https://www.google.com/favicon.ico'" />
    <span class="tab-title">${tabData.title || 'New Tab'}</span>
    <span class="tab-close" title="Close Tab">&times;</span>
  `;

  tabEl.addEventListener('click', (e) => {
    if (e.target.classList.contains('tab-close')) {
      window.stauntAPI.closeTab(tabData.id);
    } else {
      window.stauntAPI.switchTab(tabData.id);
    }
  });

  container.appendChild(tabEl);
}

function handleTabUpdated(tabData) {
  tabs.set(tabData.id, tabData);
  const tabEl = document.getElementById(`tab-${tabData.id}`);
  if (tabEl) {
    const titleSpan = tabEl.querySelector('.tab-title');
    const favImg = tabEl.querySelector('.tab-favicon');
    if (titleSpan) titleSpan.innerText = tabData.title || 'Untitled';
    if (favImg && tabData.favicon) favImg.src = tabData.favicon;
  }

  if (activeTabId === tabData.id) {
    displayOmniboxUrl(tabData.url);
  }
}

function displayOmniboxUrl(url) {
  const input = document.getElementById('omniboxInput');
  if (!url || url.includes('newtab.html') || url === 'staunt://newtab') {
    input.value = 'staunt://newtab';
  } else {
    input.value = url;
  }
}

function handleTabClosed(tabId) {
  tabs.delete(tabId);
  const tabEl = document.getElementById(`tab-${tabId}`);
  if (tabEl) tabEl.remove();
}

function handleTabSwitched(tabId) {
  setActiveTab(tabId);
}

function setActiveTab(tabId) {
  activeTabId = tabId;
  document.querySelectorAll('.tab').forEach(el => el.classList.remove('active'));
  const activeEl = document.getElementById(`tab-${tabId}`);
  if (activeEl) activeEl.classList.add('active');

  const cur = tabs.get(tabId);
  if (cur) {
    displayOmniboxUrl(cur.url);
  }
}

// Navigation state updates (canGoBack, canGoForward)
function handleNavStateChanged(state) {
  document.getElementById('btnBack').disabled = !state.canGoBack;
  document.getElementById('btnForward').disabled = !state.canGoForward;
  if (state.url) {
    displayOmniboxUrl(state.url);
  }
}

// Shield Stats
function handleShieldUpdated(stats) {
  document.getElementById('shieldCountText').innerText = `${stats.totalBlocked} Blocked`;
  document.getElementById('shieldStatAds').innerText = stats.adsBlocked;
  document.getElementById('shieldStatTrackers').innerText = stats.trackersBlocked;
  document.getElementById('shieldBandwidthSaved').innerText = `${stats.bandwidthSavedMB} MB`;
}

// Media Sniffer
function handleMediaDetected(mediaInfo) {
  detectedMediaUrl = mediaInfo.url;
  const btn = document.getElementById('mediaSnifferBtn');
  btn.classList.add('active');
  btn.title = `⚡ Download: ${mediaInfo.title || 'Media Stream'}`;
  refreshIcons();
}

// AI Copilot Actions
function askAIClick(promptText) {
  document.getElementById('aiUserInput').value = promptText;
  sendAIMessage();
}

function sendAIMessage() {
  const input = document.getElementById('aiUserInput');
  const text = input.value.trim();
  if (!text) return;

  const chatBox = document.getElementById('aiChatBox');

  // User message
  const userMsg = document.createElement('div');
  userMsg.style.cssText = 'background:rgba(139,92,246,0.2); border:1px solid rgba(139,92,246,0.3); padding:8px 12px; border-radius:8px; margin-bottom:8px; text-align:right; font-weight:500; font-size:12px;';
  userMsg.innerText = text;
  chatBox.appendChild(userMsg);

  input.value = '';

  // AI Response placeholder
  const aiMsg = document.createElement('div');
  aiMsg.style.cssText = 'background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); padding:10px 12px; border-radius:8px; margin-bottom:12px; font-size:12px; line-height:1.5; color:#e2e8f0;';
  aiMsg.innerHTML = `<span class="animate-pulse">Thinking & Analyzing page context...</span>`;
  chatBox.appendChild(aiMsg);
  chatBox.scrollTop = chatBox.scrollHeight;

  const curUrl = document.getElementById('omniboxInput').value;

  // Real in-browser analysis synthesis
  setTimeout(() => {
    aiMsg.innerHTML = `<strong>Staunt Copilot Insights:</strong><br /><br />
    Analysis of current webpage (<code>${curUrl || 'active view'}</code>):<br />
    • <strong>Key Purpose:</strong> High-speed interactive web experience.<br />
    • <strong>Security Rating:</strong> Strict HTTPS with Staunt Shield active.<br />
    • <strong>Answer to "${text}":</strong> This webpage is rendering within Staunt's isolated Chromium context. No intrusive trackers or unauthorized scripts were permitted.`;
    chatBox.scrollTop = chatBox.scrollHeight;
  }, 700);
}
