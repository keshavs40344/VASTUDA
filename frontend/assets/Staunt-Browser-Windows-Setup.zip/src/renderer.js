// Staunt Browser Ultra — Renderer Controller & State Engine
let tabs = new Map();
let activeTabId = null;
let secondaryTabId = null;
let isSplit = false;
let isSidebarCollapsed = false;

document.addEventListener('DOMContentLoaded', () => {
  lucide.createIcons();

  // Window Controls
  document.getElementById('btnWinClose').addEventListener('click', () => window.stauntAPI.closeWindow());
  document.getElementById('btnWinMin').addEventListener('click', () => window.stauntAPI.minimizeWindow());
  document.getElementById('btnWinMax').addEventListener('click', () => window.stauntAPI.maximizeWindow());

  // Navigation
  document.getElementById('btnBack').addEventListener('click', () => window.stauntAPI.goBack());
  document.getElementById('btnForward').addEventListener('click', () => window.stauntAPI.goForward());
  document.getElementById('btnReload').addEventListener('click', () => window.stauntAPI.reload());
  document.getElementById('btnDevTools').addEventListener('click', () => window.stauntAPI.toggleDevTools());
  document.getElementById('btnNewTab').addEventListener('click', () => window.stauntAPI.createTab('staunt://newtab'));
  document.getElementById('btnMuteActive').addEventListener('click', () => window.stauntAPI.toggleMuteTab(activeTabId));

  // Split View & Incognito
  document.getElementById('btnSplitView').addEventListener('click', () => window.stauntAPI.toggleSplitView());
  document.getElementById('btnIncognito').addEventListener('click', () => window.stauntAPI.createTab('staunt://newtab', { isIncognito: true }));

  // Sidebar Toggle
  document.getElementById('btnToggleSidebar').addEventListener('click', () => {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('collapsed');
    isSidebarCollapsed = sidebar.classList.contains('collapsed');
    window.stauntAPI.setSidebarState(isSidebarCollapsed);
  });

  // Command Capsule Click
  document.getElementById('commandCapsule').addEventListener('click', openPalette);

  // Palette Input
  const pInput = document.getElementById('paletteInput');
  pInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      submitPalette(pInput.value.trim());
    } else if (e.key === 'Escape') {
      closePalette();
    }
  });

  // Scratchpad Persistence
  const scratchText = document.getElementById('scratchpadText');
  scratchText.value = localStorage.getItem('staunt_scratchpad_v1') || '';
  scratchText.addEventListener('input', () => {
    localStorage.setItem('staunt_scratchpad_v1', scratchText.value);
  });
  document.getElementById('btnOpenScratchpad').addEventListener('click', toggleScratchpad);

  // Keyboard Shortcuts (Cmd+K, Ctrl+T, Ctrl+W, Ctrl+S)
  window.addEventListener('keydown', (e) => {
    const isCtrl = e.ctrlKey || e.metaKey;
    if (isCtrl && (e.key.toLowerCase() === 'k' || e.key.toLowerCase() === 'l')) {
      e.preventDefault();
      openPalette();
    } else if (isCtrl && e.key.toLowerCase() === 't') {
      e.preventDefault();
      window.stauntAPI.createTab('staunt://newtab');
    } else if (isCtrl && e.key.toLowerCase() === 'w') {
      e.preventDefault();
      if (activeTabId) window.stauntAPI.closeTab(activeTabId);
    } else if (isCtrl && e.key.toLowerCase() === 's') {
      e.preventDefault();
      document.getElementById('btnToggleSidebar').click();
    }
  });

  // IPC Event Listeners from Main Process
  window.stauntAPI.onTabCreated((tab) => {
    tabs.set(tab.id, tab);
    renderTabsList();
  });

  window.stauntAPI.onTabUpdated((tab) => {
    tabs.set(tab.id, tab);
    renderTabsList();
    if (activeTabId === tab.id) updateActiveCapsule(tab);
  });

  window.stauntAPI.onTabClosed((tabId) => {
    tabs.delete(tabId);
    renderTabsList();
  });

  window.stauntAPI.onTabSwitched((data) => {
    activeTabId = data.activeTabId;
    secondaryTabId = data.secondaryTabId;
    isSplit = data.isSplit;
    renderTabsList();
    const cur = tabs.get(activeTabId);
    if (cur) updateActiveCapsule(cur);
  });

  window.stauntAPI.onSplitViewUpdated((data) => {
    isSplit = data.isSplit;
    secondaryTabId = data.secondaryTabId;
    renderTabsList();
  });

  window.stauntAPI.onShieldUpdated((stats) => {
    document.getElementById('shieldStatusText').textContent = `${stats.totalBlocked} Blocked`;
  });

  // Start initial tab
  window.stauntAPI.createTab('staunt://newtab');
});

// Render Vertical Tabs List
function renderTabsList() {
  const container = document.getElementById('tabsList');
  container.innerHTML = '';

  tabs.forEach((tab) => {
    const el = document.createElement('div');
    el.className = `tab-item ${tab.id === activeTabId ? 'active' : ''}`;
    el.innerHTML = `
      <div style="display:flex; align-items:center; gap:8px; overflow:hidden; flex:1;">
        <img src="${tab.favicon || 'https://www.google.com/favicon.ico'}" style="width:14px; height:14px; border-radius:2px;" onerror="this.src='https://www.google.com/favicon.ico'" />
        <span style="white-space:nowrap; text-overflow:ellipsis; overflow:hidden;">${tab.title || 'Untitled'}</span>
      </div>
      <div style="display:flex; align-items:center; gap:4px;">
        ${tab.isAudioPlaying ? `<button class="audio-mute-btn" onclick="event.stopPropagation(); window.stauntAPI.toggleMuteTab(${tab.id})">${tab.isMuted ? '🔇' : '🔊'}</button>` : ''}
        <span onclick="event.stopPropagation(); window.stauntAPI.closeTab(${tab.id})" style="opacity:0.6; cursor:pointer;">&times;</span>
      </div>
    `;

    el.addEventListener('click', () => {
      window.stauntAPI.switchTab(tab.id);
    });

    container.appendChild(el);
  });

  lucide.createIcons();
}

function updateActiveCapsule(tab) {
  const title = document.getElementById('capsuleTitle');
  if (tab.url.includes('newtab.html') || tab.url === 'staunt://newtab') {
    title.textContent = 'staunt://newtab';
  } else {
    title.textContent = tab.url;
  }
}

// Preset Launcher
function openPreset(url) {
  window.stauntAPI.createTab(url);
}

// Command Palette
function openPalette() {
  const modal = document.getElementById('paletteModal');
  modal.classList.remove('hidden');
  const input = document.getElementById('paletteInput');
  input.value = '';
  input.focus();
}

function closePalette() {
  document.getElementById('paletteModal').classList.add('hidden');
}

function setPaletteText(txt) {
  const input = document.getElementById('paletteInput');
  input.value = txt;
  input.focus();
}

function submitPalette(val) {
  closePalette();
  if (!val) return;

  if (val.startsWith('>')) {
    const cmd = val.slice(1).toLowerCase().trim();
    if (cmd === 'clean') {
      window.stauntAPI.clearCache();
      alert('⚡ Browser cache & memory purged.');
    } else if (cmd === 'split') {
      window.stauntAPI.toggleSplitView();
    } else if (cmd === 'note') {
      toggleScratchpad();
    } else if (cmd === 'mute') {
      window.stauntAPI.toggleMuteTab(activeTabId);
    } else {
      alert(`Unknown terminal command: ${cmd}`);
    }
    return;
  }

  window.stauntAPI.navigate(val);
}

function toggleScratchpad() {
  const drawer = document.getElementById('scratchpadDrawer');
  drawer.classList.toggle('hidden');
}
