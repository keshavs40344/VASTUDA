@echo off
title Staunt Browser Ultra - Setup Wizard (Windows)
echo =======================================================
echo     STAUNT BROWSER ULTRA - SETUP WIZARD (Windows)
echo     Chromium 130 + V8 13.0 Core • Zero Telemetry
echo =======================================================
echo.
cd /d "%~dp0"

if exist "node_modules\electron\dist\electron.exe" (
    echo [OK] Chromium Engine is already present!
    goto launch
)

echo [*] Setting up native Chromium 130 runtime...
echo [*] Downloading high-speed runtime from official release...
powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://github.com/electron/electron/releases/download/v33.2.0/electron-v33.2.0-win32-x64.zip' -OutFile 'electron.zip'; Expand-Archive -Path 'electron.zip' -DestinationPath 'node_modules\electron\dist' -Force; Remove-Item 'electron.zip'"

if exist "node_modules\electron\dist\electron.exe" (
    echo [OK] Chromium 130 Engine successfully installed!
) else (
    echo [!] Download notice. Launching fallback...
)

:launch
echo [*] Launching Staunt Browser Ultra...
start "" "%~dp0node_modules\electron\dist\electron.exe" "%~dp0"
exit
