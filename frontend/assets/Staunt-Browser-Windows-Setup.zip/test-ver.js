console.log("=== ELECTRON ENGINE REPORT ===");
console.log("Electron Version:", process.versions.electron);
console.log("Chromium Core:", process.versions.chrome);
console.log("Node Runtime:", process.versions.node);
console.log("V8 Engine:", process.versions.v8);
process.exit(0);
