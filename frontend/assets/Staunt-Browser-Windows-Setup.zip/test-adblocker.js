const {
  isCriticalWhitelisted,
  isFirstParty,
  SURROGATES_SCRIPT,
  YOUTUBE_AD_SUPPRESSION_SCRIPT,
  SCOPED_COSMETIC_CSS
} = require('./src/adblocker-core');

console.log('======================================================');
console.log('🛡️ RUNNING ENTERPRISE AD-BLOCKER & ZERO-BREAKAGE TESTS');
console.log('======================================================\n');

let failed = 0;

function assert(condition, name) {
  if (condition) {
    console.log(`✅ [PASS] ${name}`);
  } else {
    console.error(`❌ [FAIL] ${name}`);
    failed++;
  }
}

// 1. Critical Whitelist Tests (Never Intercept or Cancel)
console.log('[STAGE 1: CRITICAL WHITELIST INTEGRITY]');
assert(isCriticalWhitelisted('https://accounts.google.com/o/oauth2/auth'), 'Google OAuth must be whitelisted');
assert(isCriticalWhitelisted('https://appleid.apple.com/auth/authorize'), 'Apple ID Sign-In must be whitelisted');
assert(isCriticalWhitelisted('https://github.com/login/oauth/authorize'), 'GitHub OAuth must be whitelisted');
assert(isCriticalWhitelisted('https://login.microsoftonline.com/common/oauth2'), 'Microsoft Login must be whitelisted');
assert(isCriticalWhitelisted('https://www.google.com/recaptcha/api.js'), 'Google reCAPTCHA must be whitelisted');
assert(isCriticalWhitelisted('https://challenges.cloudflare.com/turnstile/v0/api.js'), 'Cloudflare Turnstile must be whitelisted');
assert(isCriticalWhitelisted('https://js.stripe.com/v3/'), 'Stripe Payment Elements must be whitelisted');
assert(isCriticalWhitelisted('https://checkout.razorpay.com/v1/checkout.js'), 'Razorpay Payment Gateway must be whitelisted');
assert(isCriticalWhitelisted('https://www.paypal.com/sdk/js'), 'PayPal SDK must be whitelisted');
assert(isCriticalWhitelisted('https://cdnjs.cloudflare.com/ajax/libs/react/18.2.0/umd/react.production.min.js'), 'cdnjs CDN must be whitelisted');
assert(isCriticalWhitelisted('https://unpkg.com/vue@3/dist/vue.global.js'), 'unpkg CDN must be whitelisted');

// 2. First-Party eTLD+1 Protection Tests
console.log('\n[STAGE 2: eTLD+1 FIRST-PARTY DOMAIN MATCHING]');
assert(isFirstParty('https://api.github.com/user', 'https://github.com/dashboard'), 'api.github.com is 1st-party to github.com');
assert(isFirstParty('https://static.facebook.com/rsrc.php', 'https://www.facebook.com/'), 'static.facebook.com is 1st-party to facebook.com');
assert(isFirstParty('https://subdomain.example.co.uk/app.js', 'https://example.co.uk/home'), 'co.uk multi-level TLD handled correctly');
assert(!isFirstParty('https://google-analytics.com/analytics.js', 'https://mybank.com/portal'), 'google-analytics is NOT 1st-party to mybank.com');
assert(!isFirstParty('https://adservice.google.com/adsid/integrator.js', 'https://nytimes.com/article'), 'adservice is NOT 1st-party to nytimes.com');

// 3. Surrogates Defusing Script Tests
console.log('\n[STAGE 3: SCRIPT SURROGATES DEFUSING VERIFICATION]');
assert(SURROGATES_SCRIPT.includes('window.ga'), 'Surrogates defuse window.ga without breaking sites');
assert(SURROGATES_SCRIPT.includes('window.fbq'), 'Surrogates defuse window.fbq');
assert(SURROGATES_SCRIPT.includes('window.googletag'), 'Surrogates mock googletag pubads');
assert(SURROGATES_SCRIPT.includes('window.dataLayer'), 'Surrogates initialize dataLayer');

// 4. YouTube Ad Suppression Engine Tests
console.log('\n[STAGE 4: YOUTUBE DYNAMIC AD SUPPRESSION VERIFICATION]');
assert(YOUTUBE_AD_SUPPRESSION_SCRIPT.includes('ad-showing'), 'Detects ad-showing player state');
assert(YOUTUBE_AD_SUPPRESSION_SCRIPT.includes('video.currentTime = video.duration'), 'Safely fast-forwards ad to completion');
assert(YOUTUBE_AD_SUPPRESSION_SCRIPT.includes('.ytp-ad-skip-button'), 'Automates click on skip buttons');

// 5. Scoped Cosmetic Hiding Tests
console.log('\n[STAGE 5: SCOPED COSMETIC RULES SAFETY]');
assert(SCOPED_COSMETIC_CSS.includes('ytd-ad-slot-renderer'), 'Hides YouTube ad slot renderer');
assert(!SCOPED_COSMETIC_CSS.includes('div[class*="ad"]'), 'NEVER contains generic destructive div[class*="ad"] wildcard');

console.log('\n======================================================');
if (failed === 0) {
  console.log('🎉 ALL ZERO-BREAKAGE & AD-BLOCKER CHECKS PASSED PERFECTLY!');
} else {
  console.error(`💥 ${failed} TEST(S) FAILED!`);
  process.exit(1);
}
console.log('======================================================');
